<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Class Auth
 * @property Ion_auth|Ion_auth_model $ion_auth        The ION Auth spark
 * @property CI_Form_validation      $form_validation The form validation library
 */
class Auth extends CI_Controller
{
	public $data = [];

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
		$this->load->library(['ion_auth', 'form_validation']);
		$this->load->helper(['url', 'language']);

		$this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));

		$this->lang->load('auth');
		$this->load->config('warriror_config');	
		//$this->load->config('mailgun_config');	
		$this->load->model('Usermodel');
		$this->load->model('Warriormodel');
	}

	/**
	 * Redirect if needed, otherwise display the user list
	 */
	public function index()
	{

		if (!$this->ion_auth->logged_in())
		{
			// redirect them to the login page
			redirect('auth/login', 'refresh');
		}
		else if (!$this->ion_auth->is_admin()) // remove this elseif if you want to enable this for non-admins
		{
			// redirect them to the home page because they must be an administrator to view this
			show_error('You must be an administrator to view this page.');
		}
		else
		{
			$this->data['title'] = $this->lang->line('index_heading');
			
			// set the flash data error message if there is one
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

			//list the users
			$this->data['users'] = $this->ion_auth->users()->result();
			
			//USAGE NOTE - you can do more complicated queries like this
			//$this->data['users'] = $this->ion_auth->where('field', 'value')->users()->result();
			
			foreach ($this->data['users'] as $k => $user)
			{
				$this->data['users'][$k]->groups = $this->ion_auth->get_users_groups($user->id)->result();
			}

			$this->_render_page('auth' . DIRECTORY_SEPARATOR . 'index', $this->data);
		}
	}

	/**
	 * Log the user in
	 */
	public function login()
	{
		$this->data['title'] = $this->lang->line('login_heading');

		// validate form input
		$this->form_validation->set_rules('identity', str_replace(':', '', $this->lang->line('login_identity_label')), 'required');
		$this->form_validation->set_rules('password', str_replace(':', '', $this->lang->line('login_password_label')), 'required');

		if ($this->form_validation->run() === TRUE)
		{
			// check to see if the user is logging in
			// check for "remember me"
			$remember = (bool)$this->input->post('remember');

			if ($this->ion_auth->login($this->input->post('identity'), $this->input->post('password'), $remember))
			{
				//if the login is successful
				//redirect them back to the home page
				$this->session->set_flashdata('message', $this->ion_auth->messages());
				redirect('/', 'refresh');
			}
			else if($this->ion_auth->loginAdmin($this->input->post('identity'), $this->input->post('password'), $remember))
			{
				$this->session->set_flashdata('message', $this->ion_auth->messages());
				redirect('/', 'refresh');				
			}
			else
			{
				// if the login was un-successful
				// redirect them back to the login page
				$this->session->set_flashdata('message', $this->ion_auth->errors());
				redirect('auth/login', 'refresh'); // use redirects instead of loading views for compatibility with MY_Controller libraries
			}
		}
		else
		{
			// the user is not logging in so display the login page
			// set the flash data error message if there is one
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

			$this->data['identity'] = [
				'name' => 'identity',
				'id' => 'identity',
				'type' => 'text',
				'value' => $this->form_validation->set_value('identity'),
			];

			$this->data['password'] = [
				'name' => 'password',
				'id' => 'password',
				'type' => 'password',
			];

			$this->_render_page('auth' . DIRECTORY_SEPARATOR . 'login', $this->data);
		}
	}

	/**
	 * Log the user out
	 */
	public function logout()
	{
		$this->data['title'] = "Logout";

		// log the user out
		$this->ion_auth->logout();

		// redirect them to the login page
		redirect('login', 'refresh');
	}

	/**
	 * Change password
	 */
	public function change_password()
	{
		$this->form_validation->set_rules('old', $this->lang->line('change_password_validation_old_password_label'), 'required');
		$this->form_validation->set_rules('new', $this->lang->line('change_password_validation_new_password_label'), 'required|min_length[' . $this->config->item('min_password_length', 'ion_auth') . ']|matches[new_confirm]');
		$this->form_validation->set_rules('new_confirm', $this->lang->line('change_password_validation_new_password_confirm_label'), 'required');

		if (!$this->ion_auth->logged_in())
		{
			redirect('auth/login', 'refresh');
		}

		$user = $this->ion_auth->user()->row();

		if ($this->form_validation->run() === FALSE)
		{
			// display the form
			// set the flash data error message if there is one
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

			$this->data['min_password_length'] = $this->config->item('min_password_length', 'ion_auth');
			$this->data['old_password'] = [
				'name' => 'old',
				'id' => 'old',
				'type' => 'password',
			];
			$this->data['new_password'] = [
				'name' => 'new',
				'id' => 'new',
				'type' => 'password',
				'pattern' => '^.{' . $this->data['min_password_length'] . '}.*$',
			];
			$this->data['new_password_confirm'] = [
				'name' => 'new_confirm',
				'id' => 'new_confirm',
				'type' => 'password',
				'pattern' => '^.{' . $this->data['min_password_length'] . '}.*$',
			];
			$this->data['user_id'] = [
				'name' => 'user_id',
				'id' => 'user_id',
				'type' => 'hidden',
				'value' => $user->id,
			];

			// render
			$this->_render_page('auth' . DIRECTORY_SEPARATOR . 'change_password', $this->data);
		}
		else
		{
			$identity = $this->session->userdata('identity');

			$change = $this->ion_auth->change_password($identity, $this->input->post('old'), $this->input->post('new'));

			if ($change)
			{
				//if the password was successfully changed
				$this->session->set_flashdata('message', $this->ion_auth->messages());
				$this->logout();
			}
			else
			{
				$this->session->set_flashdata('message', $this->ion_auth->errors());
				redirect('auth/change_password', 'refresh');
			}
		}
	}

	/**
	 * Forgot password
	 */
	public function forgot_password()
	{
		$this->data['title'] = $this->lang->line('forgot_password_heading');
		
		// setting validation rules by checking whether identity is username or email
		if ($this->config->item('identity', 'ion_auth') != 'email')
		{
			$this->form_validation->set_rules('identity', $this->lang->line('forgot_password_identity_label'), 'required');
		}
		else
		{
			$this->form_validation->set_rules('identity', $this->lang->line('forgot_password_validation_email_label'), 'required|valid_email');
		}


		if ($this->form_validation->run() === FALSE)
		{
			$this->data['type'] = $this->config->item('identity', 'ion_auth');
			// setup the input
			$this->data['identity'] = [
				'name' => 'identity',
				'id' => 'identity',
			];

			if ($this->config->item('identity', 'ion_auth') != 'email')
			{
				$this->data['identity_label'] = $this->lang->line('forgot_password_identity_label');
			}
			else
			{
				$this->data['identity_label'] = $this->lang->line('forgot_password_email_identity_label');
			}

			// set any errors and display the form
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');
			$this->_render_page('auth' . DIRECTORY_SEPARATOR . 'forgot_password', $this->data);
		}
		else
		{
			$identity_column = $this->config->item('identity', 'ion_auth');
			$identity = $this->ion_auth->where($identity_column, $this->input->post('identity'))->users()->row();

			if (empty($identity))
			{

				if ($this->config->item('identity', 'ion_auth') != 'email')
				{
					$this->ion_auth->set_error('forgot_password_identity_not_found');
				}
				else
				{
					$this->ion_auth->set_error('forgot_password_email_not_found');
				}

				$this->session->set_flashdata('message', $this->ion_auth->errors());
				redirect("auth/forgot_password", 'refresh');
			}

			// run the forgotten password method to email an activation code to the user
			$forgotten = $this->ion_auth->forgotten_password($identity->{$this->config->item('identity', 'ion_auth')});

			if ($forgotten)
			{
				// if there were no errors
				$this->session->set_flashdata('message', $this->ion_auth->messages());
				redirect("auth/login", 'refresh'); //we should display a confirmation page here instead of the login page
			}
			else
			{
				$this->session->set_flashdata('message', $this->ion_auth->errors());
				redirect("auth/forgot_password", 'refresh');
			}
		}
	}

	/**
	 * Reset password - final step for forgotten password
	 *
	 * @param string|null $code The reset code
	 */
	public function reset_password($code = NULL)
	{
		if (!$code)
		{
			show_404();
		}

		$this->data['title'] = $this->lang->line('reset_password_heading');
		
		$user = $this->ion_auth->forgotten_password_check($code);

		if ($user)
		{
			// if the code is valid then display the password reset form

			$this->form_validation->set_rules('new', $this->lang->line('reset_password_validation_new_password_label'), 'required|min_length[' . $this->config->item('min_password_length', 'ion_auth') . ']|matches[new_confirm]');
			$this->form_validation->set_rules('new_confirm', $this->lang->line('reset_password_validation_new_password_confirm_label'), 'required');

			if ($this->form_validation->run() === FALSE)
			{
				// display the form

				// set the flash data error message if there is one
				$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

				$this->data['min_password_length'] = $this->config->item('min_password_length', 'ion_auth');
				$this->data['new_password'] = [
					'name' => 'new',
					'id' => 'new',
					'type' => 'password',
					'pattern' => '^.{' . $this->data['min_password_length'] . '}.*$',
				];
				$this->data['new_password_confirm'] = [
					'name' => 'new_confirm',
					'id' => 'new_confirm',
					'type' => 'password',
					'pattern' => '^.{' . $this->data['min_password_length'] . '}.*$',
				];
				$this->data['user_id'] = [
					'name' => 'user_id',
					'id' => 'user_id',
					'type' => 'hidden',
					'value' => $user->id,
				];
				$this->data['csrf'] = $this->_get_csrf_nonce();
				$this->data['code'] = $code;

				// render
				$this->_render_page('auth' . DIRECTORY_SEPARATOR . 'reset_password', $this->data);
			}
			else
			{
				$identity = $user->{$this->config->item('identity', 'ion_auth')};

				// do we have a valid request?
				if ($this->_valid_csrf_nonce() === FALSE || $user->id != $this->input->post('user_id'))
				{

					// something fishy might be up
					$this->ion_auth->clear_forgotten_password_code($identity);

					show_error($this->lang->line('error_csrf'));

				}
				else
				{
					// finally change the password
					$change = $this->ion_auth->reset_password($identity, $this->input->post('new'));

					if ($change)
					{
						// if the password was successfully changed
						$this->session->set_flashdata('message', $this->ion_auth->messages());
						redirect("auth/login", 'refresh');
					}
					else
					{
						$this->session->set_flashdata('message', $this->ion_auth->errors());
						redirect('auth/reset_password/' . $code, 'refresh');
					}
				}
			}
		}
		else
		{
			// if the code is invalid then send them back to the forgot password page
			$this->session->set_flashdata('message', $this->ion_auth->errors());
			redirect("auth/forgot_password", 'refresh');
		}
	}

	/**
	 * Activate the user
	 *
	 * @param int         $id   The user ID
	 * @param string|bool $code The activation code
	 */
	public function activate($id, $code = FALSE)
	{
		$activation = FALSE;

		if ($code !== FALSE)
		{
			$activation = $this->ion_auth->activate($id, $code);
		}
		else if ($this->ion_auth->is_admin())
		{
			$activation = $this->ion_auth->activate($id);
		}

		if ($activation)
		{
			// redirect them to the auth page
			$this->session->set_flashdata('message', $this->ion_auth->messages());
			redirect("auth", 'refresh');
		}
		else
		{
			// redirect them to the forgot password page
			$this->session->set_flashdata('message', $this->ion_auth->errors());
			redirect("auth/forgot_password", 'refresh');
		}
	}

	/**
	 * Deactivate the user
	 *
	 * @param int|string|null $id The user ID
	 */
	public function deactivate($id = NULL)
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin())
		{
			// redirect them to the home page because they must be an administrator to view this
			show_error('You must be an administrator to view this page.');
		}

		$id = (int)$id;

		$this->load->library('form_validation');
		$this->form_validation->set_rules('confirm', $this->lang->line('deactivate_validation_confirm_label'), 'required');
		$this->form_validation->set_rules('id', $this->lang->line('deactivate_validation_user_id_label'), 'required|alpha_numeric');

		if ($this->form_validation->run() === FALSE)
		{
			// insert csrf check
			$this->data['csrf'] = $this->_get_csrf_nonce();
			$this->data['user'] = $this->ion_auth->user($id)->row();

			$this->_render_page('auth' . DIRECTORY_SEPARATOR . 'deactivate_user', $this->data);
		}
		else
		{
			// do we really want to deactivate?
			if ($this->input->post('confirm') == 'yes')
			{
				// do we have a valid request?
				if ($this->_valid_csrf_nonce() === FALSE || $id != $this->input->post('id'))
				{
					show_error($this->lang->line('error_csrf'));
				}

				// do we have the right userlevel?
				if ($this->ion_auth->logged_in() && $this->ion_auth->is_admin())
				{
					$this->ion_auth->deactivate($id);
				}
			}

			// redirect them back to the auth page
			redirect('auth', 'refresh');
		}
	}

	/**
	 * Create a new user
	 */
	public function create_user()
	{
		$this->data['title'] = $this->lang->line('create_user_heading');

		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin())
		{
			redirect('auth', 'refresh');
		}

		$tables = $this->config->item('tables', 'ion_auth');
		$identity_column = $this->config->item('identity', 'ion_auth');
		$this->data['identity_column'] = $identity_column;

		// validate form input
		$this->form_validation->set_rules('first_name', $this->lang->line('create_user_validation_fname_label'), 'trim|required');
		$this->form_validation->set_rules('last_name', $this->lang->line('create_user_validation_lname_label'), 'trim|required');
		if ($identity_column !== 'email')
		{
			$this->form_validation->set_rules('identity', $this->lang->line('create_user_validation_identity_label'), 'trim|required|is_unique[' . $tables['users'] . '.' . $identity_column . ']');
			$this->form_validation->set_rules('email', $this->lang->line('create_user_validation_email_label'), 'trim|required|valid_email');
		}
		else
		{
			$this->form_validation->set_rules('email', $this->lang->line('create_user_validation_email_label'), 'trim|required|valid_email|is_unique[' . $tables['users'] . '.email]');
		}
		$this->form_validation->set_rules('phone', $this->lang->line('create_user_validation_phone_label'), 'trim');
		$this->form_validation->set_rules('company', $this->lang->line('create_user_validation_company_label'), 'trim');
		$this->form_validation->set_rules('password', $this->lang->line('create_user_validation_password_label'), 'required|min_length[' . $this->config->item('min_password_length', 'ion_auth') . ']|matches[password_confirm]');
		$this->form_validation->set_rules('password_confirm', $this->lang->line('create_user_validation_password_confirm_label'), 'required');

		if ($this->form_validation->run() === TRUE)
		{
			$email = strtolower($this->input->post('email'));
			$identity = ($identity_column === 'email') ? $email : $this->input->post('identity');
			$password = $this->input->post('password');

			$additional_data = [
				'first_name' => $this->input->post('first_name'),
				'last_name' => $this->input->post('last_name'),
				'company' => $this->input->post('company'),
				'phone' => $this->input->post('phone'),
			];
		}
		if ($this->form_validation->run() === TRUE && $this->ion_auth->register($identity, $password, $email, $additional_data))
		{
			// check to see if we are creating the user
			// redirect them back to the admin page
			$this->session->set_flashdata('message', $this->ion_auth->messages());
			redirect("auth", 'refresh');
		}
		else
		{
			// display the create user form
			// set the flash data error message if there is one
			$this->data['message'] = (validation_errors() ? validation_errors() : ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message')));

			$this->data['first_name'] = [
				'name' => 'first_name',
				'id' => 'first_name',
				'type' => 'text',
				'value' => $this->form_validation->set_value('first_name'),
			];
			$this->data['last_name'] = [
				'name' => 'last_name',
				'id' => 'last_name',
				'type' => 'text',
				'value' => $this->form_validation->set_value('last_name'),
			];
			$this->data['identity'] = [
				'name' => 'identity',
				'id' => 'identity',
				'type' => 'text',
				'value' => $this->form_validation->set_value('identity'),
			];
			$this->data['email'] = [
				'name' => 'email',
				'id' => 'email',
				'type' => 'text',
				'value' => $this->form_validation->set_value('email'),
			];
			$this->data['company'] = [
				'name' => 'company',
				'id' => 'company',
				'type' => 'text',
				'value' => $this->form_validation->set_value('company'),
			];
			$this->data['phone'] = [
				'name' => 'phone',
				'id' => 'phone',
				'type' => 'text',
				'value' => $this->form_validation->set_value('phone'),
			];
			$this->data['password'] = [
				'name' => 'password',
				'id' => 'password',
				'type' => 'password',
				'value' => $this->form_validation->set_value('password'),
			];
			$this->data['password_confirm'] = [
				'name' => 'password_confirm',
				'id' => 'password_confirm',
				'type' => 'password',
				'value' => $this->form_validation->set_value('password_confirm'),
			];

			$this->_render_page('auth' . DIRECTORY_SEPARATOR . 'create_user', $this->data);
		}
	}
	/**
	* Redirect a user checking if is admin
	*/
	public function redirectUser(){
		if ($this->ion_auth->is_admin()){
			redirect('auth', 'refresh');
		}
		redirect('/', 'refresh');
	}

	/**
	 * Edit a user
	 *
	 * @param int|string $id
	 */
	public function edit_user($id)
	{
		$this->data['title'] = $this->lang->line('edit_user_heading');

		if (!$this->ion_auth->logged_in() || (!$this->ion_auth->is_admin() && !($this->ion_auth->user()->row()->id == $id)))
		{
			redirect('auth', 'refresh');
		}

		$user = $this->ion_auth->user($id)->row();
		$groups = $this->ion_auth->groups()->result_array();
		$currentGroups = $this->ion_auth->get_users_groups($id)->result();
			
		//USAGE NOTE - you can do more complicated queries like this
		//$groups = $this->ion_auth->where(['field' => 'value'])->groups()->result_array();
	

		// validate form input
		$this->form_validation->set_rules('first_name', $this->lang->line('edit_user_validation_fname_label'), 'trim|required');
		$this->form_validation->set_rules('last_name', $this->lang->line('edit_user_validation_lname_label'), 'trim|required');
		$this->form_validation->set_rules('phone', $this->lang->line('edit_user_validation_phone_label'), 'trim');
		$this->form_validation->set_rules('company', $this->lang->line('edit_user_validation_company_label'), 'trim');

		if (isset($_POST) && !empty($_POST))
		{
			// do we have a valid request?
			if ($this->_valid_csrf_nonce() === FALSE || $id != $this->input->post('id'))
			{
				show_error($this->lang->line('error_csrf'));
			}

			// update the password if it was posted
			if ($this->input->post('password'))
			{
				$this->form_validation->set_rules('password', $this->lang->line('edit_user_validation_password_label'), 'required|min_length[' . $this->config->item('min_password_length', 'ion_auth') . ']|matches[password_confirm]');
				$this->form_validation->set_rules('password_confirm', $this->lang->line('edit_user_validation_password_confirm_label'), 'required');
			}

			if ($this->form_validation->run() === TRUE)
			{
				$data = [
					'first_name' => $this->input->post('first_name'),
					'last_name' => $this->input->post('last_name'),
					'company' => $this->input->post('company'),
					'phone' => $this->input->post('phone'),
				];

				// update the password if it was posted
				if ($this->input->post('password'))
				{
					$data['password'] = $this->input->post('password');
				}

				// Only allow updating groups if user is admin
				if ($this->ion_auth->is_admin())
				{
					// Update the groups user belongs to
					$this->ion_auth->remove_from_group('', $id);
					
					$groupData = $this->input->post('groups');
					if (isset($groupData) && !empty($groupData))
					{
						foreach ($groupData as $grp)
						{
							$this->ion_auth->add_to_group($grp, $id);
						}

					}
				}

				// check to see if we are updating the user
				if ($this->ion_auth->update($user->id, $data))
				{
					// redirect them back to the admin page if admin, or to the base url if non admin
					$this->session->set_flashdata('message', $this->ion_auth->messages());
					$this->redirectUser();

				}
				else
				{
					// redirect them back to the admin page if admin, or to the base url if non admin
					$this->session->set_flashdata('message', $this->ion_auth->errors());
					$this->redirectUser();

				}

			}
		}

		// display the edit user form
		$this->data['csrf'] = $this->_get_csrf_nonce();

		// set the flash data error message if there is one
		$this->data['message'] = (validation_errors() ? validation_errors() : ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message')));

		// pass the user to the view
		$this->data['user'] = $user;
		$this->data['groups'] = $groups;
		$this->data['currentGroups'] = $currentGroups;

		$this->data['first_name'] = [
			'name'  => 'first_name',
			'id'    => 'first_name',
			'type'  => 'text',
			'value' => $this->form_validation->set_value('first_name', $user->first_name),
		];
		$this->data['last_name'] = [
			'name'  => 'last_name',
			'id'    => 'last_name',
			'type'  => 'text',
			'value' => $this->form_validation->set_value('last_name', $user->last_name),
		];
		$this->data['company'] = [
			'name'  => 'company',
			'id'    => 'company',
			'type'  => 'text',
			'value' => $this->form_validation->set_value('company', $user->company),
		];
		$this->data['phone'] = [
			'name'  => 'phone',
			'id'    => 'phone',
			'type'  => 'text',
			'value' => $this->form_validation->set_value('phone', $user->phone),
		];
		$this->data['password'] = [
			'name' => 'password',
			'id'   => 'password',
			'type' => 'password'
		];
		$this->data['password_confirm'] = [
			'name' => 'password_confirm',
			'id'   => 'password_confirm',
			'type' => 'password'
		];

		$this->_render_page('auth/edit_user', $this->data);
	}

	/**
	 * Create a new group
	 */
	public function create_group()
	{
		$this->data['title'] = $this->lang->line('create_group_title');

		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin())
		{
			redirect('auth', 'refresh');
		}

		// validate form input
		$this->form_validation->set_rules('group_name', $this->lang->line('create_group_validation_name_label'), 'trim|required|alpha_dash');

		if ($this->form_validation->run() === TRUE)
		{
			$new_group_id = $this->ion_auth->create_group($this->input->post('group_name'), $this->input->post('description'));
			if ($new_group_id)
			{
				// check to see if we are creating the group
				// redirect them back to the admin page
				$this->session->set_flashdata('message', $this->ion_auth->messages());
				redirect("auth", 'refresh');
			}
			else
            		{
				$this->session->set_flashdata('message', $this->ion_auth->errors());
            		}			
		}
			
		// display the create group form
		// set the flash data error message if there is one
		$this->data['message'] = (validation_errors() ? validation_errors() : ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message')));

		$this->data['group_name'] = [
			'name'  => 'group_name',
			'id'    => 'group_name',
			'type'  => 'text',
			'value' => $this->form_validation->set_value('group_name'),
		];
		$this->data['description'] = [
			'name'  => 'description',
			'id'    => 'description',
			'type'  => 'text',
			'value' => $this->form_validation->set_value('description'),
		];

		$this->_render_page('auth/create_group', $this->data);
		
	}

	/**
	 * Edit a group
	 *
	 * @param int|string $id
	 */
	public function edit_group($id)
	{
		// bail if no group id given
		if (!$id || empty($id))
		{
			redirect('auth', 'refresh');
		}

		$this->data['title'] = $this->lang->line('edit_group_title');

		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin())
		{
			redirect('auth', 'refresh');
		}

		$group = $this->ion_auth->group($id)->row();

		// validate form input
		$this->form_validation->set_rules('group_name', $this->lang->line('edit_group_validation_name_label'), 'trim|required|alpha_dash');

		if (isset($_POST) && !empty($_POST))
		{
			if ($this->form_validation->run() === TRUE)
			{
				$group_update = $this->ion_auth->update_group($id, $_POST['group_name'], array(
					'description' => $_POST['group_description']
				));

				if ($group_update)
				{
					$this->session->set_flashdata('message', $this->lang->line('edit_group_saved'));
					redirect("auth", 'refresh');
				}
				else
				{
					$this->session->set_flashdata('message', $this->ion_auth->errors());
				}				
			}
		}

		// set the flash data error message if there is one
		$this->data['message'] = (validation_errors() ? validation_errors() : ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message')));

		// pass the user to the view
		$this->data['group'] = $group;

		$this->data['group_name'] = [
			'name'    => 'group_name',
			'id'      => 'group_name',
			'type'    => 'text',
			'value'   => $this->form_validation->set_value('group_name', $group->name),
		];
		if ($this->config->item('admin_group', 'ion_auth') === $group->name) {
			$this->data['group_name']['readonly'] = 'readonly';
		}
		
		$this->data['group_description'] = [
			'name'  => 'group_description',
			'id'    => 'group_description',
			'type'  => 'text',
			'value' => $this->form_validation->set_value('group_description', $group->description),
		];

		$this->_render_page('auth' . DIRECTORY_SEPARATOR . 'edit_group', $this->data);
	}

	/**
	 * @return array A CSRF key-value pair
	 */
	public function _get_csrf_nonce()
	{
		$this->load->helper('string');
		$key = random_string('alnum', 8);
		$value = random_string('alnum', 20);
		$this->session->set_flashdata('csrfkey', $key);
		$this->session->set_flashdata('csrfvalue', $value);

		return [$key => $value];
	}

	/**
	 * @return bool Whether the posted CSRF token matches
	 */
	public function _valid_csrf_nonce(){
		$csrfkey = $this->input->post($this->session->flashdata('csrfkey'));
		if ($csrfkey && $csrfkey === $this->session->flashdata('csrfvalue'))
		{
			return TRUE;
		}
			return FALSE;
	}

	/**
	 * @param string     $view
	 * @param array|null $data
	 * @param bool       $returnhtml
	 *
	 * @return mixed
	 */
	public function _render_page($view, $data = NULL, $returnhtml = FALSE)//I think this makes more sense
	{

		$viewdata = (empty($data)) ? $this->data : $data;

		$view_html = $this->load->view($view, $viewdata, $returnhtml);

		// This will return html on 3rd argument being true
		if ($returnhtml)
		{
			return $view_html;
		}
	}
	
		//log the user in
	function jvZooListener()
	{
		
		$ccustname = null;
		$ccuststate = null;
		$ccustcc = null;
		$ccustemail = null;
		$cproditem = null;
		$cprodtitle = null;
		$cprodtype = null;
		$ctransaction = null;
		$ctransaffiliate = null;
		$ctransamount = null;
		$ctranspaymentmethod = null;
		$ctransvendor = null;
		$ctransreceipt = null;
		$cupsellreceipt = null;
		$caffitid = null;
		$cvendthru = null;
		$cverify = null;
		$ctranstime = null;
		
		$this->Jvzoolistenermodel->ReceivedOn = date('Y/m/d H:i:s', time());
		$ret = $this->Jvzoolistenermodel->create(1);
		
		if (!$ret){
			$msg = "JvZoo - listenerJvZoo - Begin Content - ".$this->Jvzoolistenermodel->Error;
			echo $msg;
			//Common::sendAdministrativeMail($msg);
			return;
		}else{
			$this->Jvzoolistenermodel->JvZooLientener_id = $ret;
		}
		
		// STEP 1: read POST data
 		
		// Reading POSTed data directly from $_REQUEST causes serialization issues with array data in the POST.
		// Instead, read raw POST data from the input stream.
		$raw_post_data = file_get_contents('php://input');
		
		//update the Content receive for JvZoo;
		$this->Jvzoolistenermodel->Content = $raw_post_data;
		
		$ret = $this->Jvzoolistenermodel->create(2);
		
		if (!$ret){
			$msg = "JvZoo - listenerJvZoo - Create Content - ".$this->Jvzoolistenermodel->Error;
			echo $msg;
			//Common::sendAdministrativeMail($msg);
			return;
		}
		
		$raw_post_array = explode('&', $raw_post_data);
		
		// inspect IPN validation result and act accordingly
		//if ($this->jvzIpnVerification()) {
		$jvq=1;
		if ($jvq == 1) {
			
			// The IPN is verified, process it:
			// check whether the payment_status is Completed
			// check that receiver_email is your Primary PayPal email
			// check that payment_amount/payment_currency are correct
			// process the notification
			 
			// assign posted variables to local variables
			if (isset($_REQUEST['ccustname'])) $ccustname = $_REQUEST['ccustname'];
			if (isset($_REQUEST['ccuststate'])) $ccuststate = $_REQUEST['ccuststate'];
			if (isset($_REQUEST['ccustcc'])) $ccustcc = $_REQUEST['ccustcc'];
			if (isset($_REQUEST['ccustemail'])) $ccustemail = $_REQUEST['ccustemail'];
			if (isset($_REQUEST['cproditem'])) $cproditem = $_REQUEST['cproditem'];
			if (isset($_REQUEST['cprodtitle'])) $cprodtitle = $_REQUEST['cprodtitle'];
			if (isset($_REQUEST['cprodtype'])) $cprodtype = $_REQUEST['cprodtype'];
			if (isset($_REQUEST['ctransaction'])) $ctransaction = $_REQUEST['ctransaction'];
			if (isset($_REQUEST['ctransaffiliate'])) $ctransaffiliate = $_REQUEST['ctransaffiliate'];
			if (isset($_REQUEST['ctransamount'])) $ctransamount = $_REQUEST['ctransamount'];
			if (isset($_REQUEST['ctranspaymentmethod'])) $ctranspaymentmethod = $_REQUEST['ctranspaymentmethod'];
			if (isset($_REQUEST['ctransvendor'])) $ctransvendor = $_REQUEST['ctransvendor'];
			if (isset($_REQUEST['ctransreceipt'])) $ctransreceipt = $_REQUEST['ctransreceipt'];
			if (isset($_REQUEST['cupsellreceipt'])) $cupsellreceipt = $_REQUEST['cupsellreceipt'];
			if (isset($_REQUEST['caffitid'])) $caffitid = $_REQUEST['caffitid'];
			if (isset($_REQUEST['cvendthru'])) $cvendthru = $_REQUEST['cvendthru'];
			if (isset($_REQUEST['cverify'])) $cverify = $_REQUEST['cverify'];
			if (isset($_REQUEST['ctranstime'])) $ctranstime = date('Y/m/d H:i:s', strtotime($_REQUEST['ctranstime']));
			
			//Save the payment informations
			$this->Jvzoolistenermodel->CCustName = $ccustname;
			$this->Jvzoolistenermodel->CCustState = $ccuststate;
			$this->Jvzoolistenermodel->CCustCc = $ccustcc;
			$this->Jvzoolistenermodel->CCustEmail = $ccustemail;
			$this->Jvzoolistenermodel->CProdItem = $cproditem;
			$this->Jvzoolistenermodel->CProdTitle = $cprodtitle;
			$this->Jvzoolistenermodel->CProdType = $cprodtype;
			$this->Jvzoolistenermodel->CTransaction = $ctransaction;
			$this->Jvzoolistenermodel->CTransAffiliate = $ctransaffiliate;
			$this->Jvzoolistenermodel->CTransAmount = $ctransamount;
			$this->Jvzoolistenermodel->CTransPaymentMethod = $ctranspaymentmethod;
			$this->Jvzoolistenermodel->CTransVendor = $ctransvendor;
			$this->Jvzoolistenermodel->CUpsellReceipt = $cupsellreceipt;
			$this->Jvzoolistenermodel->CAffitID = $caffitid;
			$this->Jvzoolistenermodel->CVendThru = $cvendthru;
			$this->Jvzoolistenermodel->CVerify = $cverify;
			$this->Jvzoolistenermodel->CTransTime = $ctranstime;
			$this->Jvzoolistenermodel->UpdatedOn = date('Y/m/d H:i:s', time());
			
			$ret = $this->Jvzoolistenermodel->create(3);
		
			if (!$ret){
				$msg = "JvZoo - listenerJvZoo - Create Content Detail - ".$this->Jvzoolistenermodel->Error;
				echo $msg;
				//Common::sendAdministrativeMail($msg);
				return;
			}
			
			//In case this is the first payment, create an Authorization to register on the system
			if (strtoupper($ctransaction) == 'SALE'){
				
				//set the bodyMessage and CreatedBy User
				$bodyEmail = null; 
				
				$profile = $this->ion_auth->where('username', $ccustemail)->users()->row(); //pass the code to profile
				//in case the user is new, create it.
				if (!$profile) {
										
					
					//configure the products from jvzoo
					$fe = $this->config->item('fe', 'jvzoo');
					$oto1 = $this->config->item('oto1', 'jvzoo');
					$oto2 = $this->config->item('oto2', 'jvzoo');
					$oto3 = $this->config->item('oto3', 'jvzoo');
					
					//Define the User Type according to the price of the payment
					if(strpos($fe, $this->Jvzoolistenermodel->CProdItem) !== false) {
						$access = 1;
					}elseif(strpos($oto1, $this->Jvzoolistenermodel->CProdItem) !== false) {
						$access = '1,2';
					}elseif(strpos($oto2, $this->Jvzoolistenermodel->CProdItem) !== false) {
						$access = '1,2,3';
					}elseif(strpos($oto3, $this->Jvzoolistenermodel->CProdItem) !== false) {
						$access = '1,2,3,4';
					}
					$pass = md5(uniqid(rand(0,5), true));
					$pass = (strlen($pass) > 8) ? substr($pass,0,7): $pass;		
					if(isset($access))
					{
						$this->ion_auth->register($ccustemail, '6sg63SA' , $ccustemail, array('first_name'=>$ccustname,'product_id'=>$this->Jvzoolistenermodel->CProdItem ), array('2'), true, $access);
						//$this->selectautoresponder($access);
					}
					//in case the user already exists, update its access
					
                    $user_id=$this->Usermodel->get_user_id($ccustemail);
					//$this->generate_invoice($access,$user_id,$ccustemail,$ccustname,$this->Jvzoolistenermodel->ReceivedOn,$this->Jvzoolistenermodel->CProdTitle,$this->Jvzoolistenermodel->CCustCc,$this->Jvzoolistenermodel->CTransAmount);
				}else{
					
					$access = 1;
					
					//configure the products from jvzoo
					$fe = $this->config->item('fe', 'jvzoo');
					$oto1 = $this->config->item('oto1', 'jvzoo');
					$oto2 = $this->config->item('oto2', 'jvzoo');
					$oto3 = $this->config->item('oto3', 'jvzoo');
					
					//Define the User Type according to the price of the payment
					if(strpos($fe, $this->Jvzoolistenermodel->CProdItem) !== false) {
						$access = '1';
					}elseif(strpos($oto1, $this->Jvzoolistenermodel->CProdItem) !== false) {
						$access = '2';
					}elseif(strpos($oto2, $this->Jvzoolistenermodel->CProdItem) !== false) {
						$access = '3';
					}elseif(strpos($oto3, $this->Jvzoolistenermodel->CProdItem) !== false) {
						$access = '4';
					}
					
					$pos = strpos(','.$profile->access, ','.$access);
					//var_dump($pos);
					
					if($pos === false) {
						$profile->access .= ','.$access;
						//update user
						$this->Usermodel->updateUserAccess($profile->id, $profile->access ,$this->Jvzoolistenermodel->CProdItem);
						$data ='';
						//$this->selectautoresponder($access);
						//  Generate invoice code start
						//$this->generate_invoice($access,$profile->id,$ccustemail,$ccustname,$this->Jvzoolistenermodel->ReceivedOn,$this->Jvzoolistenermodel->CProdTitle,$this->Jvzoolistenermodel->CCustCc,$this->Jvzoolistenermodel->CTransAmount);
						//  Generate invoice code end
				if($access=='2' || $access=='21')
				{	
					//echo $access."inside upgrade1";
					$this->load->library('email'); 		
				
					$message = $this->load->view($this->config->item('email_templates', 'ion_auth').$this->config->item('email_upgrade', 'ion_auth'),  $data, true);
				
					//$message = 'Congrats you are successfully Upgraded!!';

				$this->email->clear();
				$this->email->from($this->config->item('admin_email', 'ion_auth'), $this->config->item('site_title', 'ion_auth'));
				$this->email->to($ccustemail);
				$this->email->subject($this->config->item('site_title', 'ion_auth') . ' - Pro Access');
				$this->email->message($message);
				
								if ($this->email->send() == TRUE)
							{
					//print(1);
							echo "Successfully upgraded for upgrade1 access";
								
								//$this->set_message('activation_email_successful');
								//return $id;
							}else{
								echo "hello";
							}
					}						
				if($access=='3')
					{	

					//echo $access."inside upgrade1";
				$this->load->library('email'); 		
				
				$message = $this->load->view($this->config->item('email_templates', 'ion_auth').$this->config->item('email_upgrade2', 'ion_auth'), $data,  true);
				
				//$message = 'Congrats you are successfully Upgraded!!';

				$this->email->clear();
				$this->email->from($this->config->item('admin_email', 'ion_auth'), $this->config->item('site_title', 'ion_auth'));
				$this->email->to($ccustemail);
				$this->email->subject($this->config->item('site_title', 'ion_auth') . ' - _DFY Store');
				$this->email->message($message);
				
								if ($this->email->send() == TRUE)
							{
					//print(1);
								echo "Successfully upgraded for upgrade2 access";
								
								//$this->set_message('activation_email_successful');
								//return $id;
							}else{
								//die($this->email->print_debugger());
								//return FALSE;
								//print(2);
							}
					}	
					
					if($access=='4' || $access == '41')
					{
					$this->nicheaccess($ccustemail,$ccustname);
					//echo $access."inside upgrade1";
				$this->load->library('email'); 		
				
				$message = $this->load->view($this->config->item('email_templates', 'ion_auth').$this->config->item('email_upgrade3', 'ion_auth'), $data,  true);
				
				//$message = 'Congrats you are successfully Upgraded!!';

				$this->email->clear();
				$this->email->from($this->config->item('admin_email', 'ion_auth'), $this->config->item('site_title', 'ion_auth'));
				$this->email->to($ccustemail);
				$this->email->subject($this->config->item('site_title', 'ion_auth') . ' - Niche-Evo
');
				$this->email->message($message);
				
								if ($this->email->send() == TRUE)
							{
					//print(1);
								echo "Successfully upgraded for upgrade3 access";
								
								//$this->set_message('activation_email_successful');
								//return $id;
							}else{
								//die($this->email->print_debugger());
								//return FALSE;
								//print(2);
							}
					}						
					}
				}
			}else if(strtoupper($ctransaction) == 'RFND'){
				$msg = "JvZoo - Refunded - <b>UserID</b>:".$ccustemail;
				//Common::sendAdministrativeMail($msg);
			}else if(strtoupper($ctransaction) == 'CGBK'){
				$msg = "JvZoo - ChargeBack  - <b>UserID</b>:".$ccustemail;
				//Common::sendAdministrativeMail($msg);
			}else if(strtoupper($ctransaction) == 'INSF'){
				$msg = "JvZoo - ECheck ChargeBack  - <b>UserID</b>:".$ccustemail;
				//Common::sendAdministrativeMail($msg);
			}else if(strtoupper($ctransaction) == 'CANCEL-REBILL'){
				$msg = "JvZoo - Cancellation of a Recurring Billing - <b>UserID</b>:".$ccustemail;
				//Common::sendAdministrativeMail($msg);
			}else if(strtoupper($ctransaction) == 'UNCANCEL-REBILL'){
				$msg = "JvZoo - Reversing the Cancellation of a Recurring Billing - <b>UserID</b>:".$ccustemail;
				//Common::sendAdministrativeMail($msg);
			}
			
			echo "IPN received successfully.";
			
			exit;
			 
			// IPN message values depend upon the type of notification sent.
			// To loop through the &_POST array and print the NV pairs to the screen:
			//foreach($_REQUEST as $key => $value) {
			//	echo $key." = ". $value."<br>";
			//}
		} else {
			$msg = "JvZoo - listenerJvZoo - Invalid IPN call - <b>Data</b>:".$raw_post_data;
			//Common::sendAdministrativeMail($msg);
			// IPN invalid, log for manual investigation
			echo "JvZoo - listenerJvZoo - Invalid IPN call";
			return;
			//echo "The response from IPN was: <b>" .$res ."</b>";
		}
		return;
	}
	
	
	//warrior plus
	function warriorlistener()
	{
		$value="inserted";
		$this->Warriormodel->insertValue($value);
		$WP_TXNID = null;
		$WP_SALEID = null;
		$WP_TRANSACTION_DATE = null;
		$WP_ACTION = null;
		$WP_PAYMETHOD = null;
		$WP_SUBSCR_ID = null;
		$WP_SUBSCR_STATUS = null;
		$WP_AFFID = null;
		$WP_SUBSCR_PAYMENT_NUM = null;
		$WP_SUBSCR_PAYMENT_AMOUNT  = null;
		$WP_SUBSCR_PAYMENT_TXNID = null;
		$WP_SUBSCR_NEXT_PAYMENT_DATE  = null;
		$WP_ITEM_NAME = null;
		$WP_ITEM_NUMBER = null;
		$WP_SALE_AMOUNT = null;
		$WP_BUYER_NAME = null;
		$WP_SALE_CURRENCY = null;
		$WP_BUYER_EMAIL = null;
		$WP_SECURITYKEY = null;
		
		$this->Warriormodel->ReceivedOn = date('Y/m/d H:i:s', time());
		$ret = $this->Warriormodel->create(1);
		 // echo $ret;exit();
		if (!$ret){
			$msg = "Warriorplus - listenerWarriorplus - Begin Content - ".$this->Warriormodel->Error;
			echo $msg;
			//Common::sendAdministrativeMail($msg);
			return;
			
		}else{
			$this->Warriormodel->WarriorListener_id = $ret;
		}
        		
		// STEP 1: read POST data
 		
		// Reading POSTed data directly from $_REQUEST causes serialization issues with array data in the POST.
		// Instead, read raw POST data from the input stream.
		$raw_post_data = file_get_contents('php://input');
		
		//update the Content receive for JvZoo;
		$this->Warriormodel->Content = $raw_post_data;
		
		$ret = $this->Warriormodel->create(2);
		
		if (!$ret){
			$msg = "Warriorplus - listenerWarriorplus- Create Content - ".$this->Warriormodel->Error;
			echo $msg;
			//Common::sendAdministrativeMail($msg);
			return;
		}
		
		$raw_post_array = explode('&', $raw_post_data);
		
		// inspect IPN validation result and act accordingly
		//if ($this->jvzIpnVerification()) {
		$status = false;
		$jvq=$this->config->item('secret', 'warrior');
		
		if (!empty($jvq)){
			if(isset($_REQUEST['WP_SECURITYKEY'])){
				
			if ($jvq == $_REQUEST['WP_SECURITYKEY']){
				$status = true;
			}else{
				$status = false;
			}
			}
		}else{
			$status = true;
		}
		if ($status) 
		{
			
			// The IPN is verified, process it:
			// check whether the payment_status is Completed
			// check that receiver_email is your Primary PayPal email
			// check that payment_amount/payment_currency are correct
			// process the notification
			 
			// assign posted variables to local variables
			if (isset($_REQUEST['WP_TXNID'])) $WP_TXNID = $_REQUEST['WP_TXNID'];
			if (isset($_REQUEST['WP_SALEID'])) $WP_SALEID = $_REQUEST['WP_SALEID'];
			if (isset($_REQUEST['WP_TRANSACTION_DATE'])) $WP_TRANSACTION_DATE = date('Y/m/d H:i:s', strtotime($_REQUEST['WP_TRANSACTION_DATE']));
			if (isset($_REQUEST['WP_ACTION'])) $WP_ACTION = $_REQUEST['WP_ACTION'];
			if (isset($_REQUEST['WP_PAYMETHOD'])) $WP_PAYMETHOD = $_REQUEST['WP_PAYMETHOD'];
			if (isset($_REQUEST['WP_SUBSCR_ID'])) $WP_SUBSCR_ID = $_REQUEST['WP_SUBSCR_ID'];
			if (isset($_REQUEST['WP_SUBSCR_STATUS'])) $WP_SUBSCR_STATUS = $_REQUEST['WP_SUBSCR_STATUS'];
			if (isset($_REQUEST['WP_AFFID'])) $WP_AFFID = $_REQUEST['WP_AFFID'];
			if (isset($_REQUEST['WP_SUBSCR_PAYMENT_NUM'])) $WP_SUBSCR_PAYMENT_NUM = $_REQUEST['WP_SUBSCR_PAYMENT_NUM'];
			if (isset($_REQUEST['WP_SUBSCR_PAYMENT_AMOUNT '])) $WP_SUBSCR_PAYMENT_AMOUNT  = $_REQUEST['WP_SUBSCR_PAYMENT_AMOUNT '];
			if (isset($_REQUEST['WP_SUBSCR_PAYMENT_TXNID '])) $WP_SUBSCR_PAYMENT_TXNID  = $_REQUEST['WP_SUBSCR_PAYMENT_TXNID '];
			if (isset($_REQUEST['WP_SUBSCR_NEXT_PAYMENT_DATE '])) $WP_SUBSCR_NEXT_PAYMENT_DATE  = $_REQUEST['WP_SUBSCR_NEXT_PAYMENT_DATE '];
			if (isset($_REQUEST['WP_ITEM_NAME'])) $WP_ITEM_NAME = $_REQUEST['WP_ITEM_NAME'];
			if (isset($_REQUEST['WP_ITEM_NUMBER'])) $WP_ITEM_NUMBER = $_REQUEST['WP_ITEM_NUMBER'];
			if (isset($_REQUEST['WP_SALE_AMOUNT'])) $WP_SALE_AMOUNT = $_REQUEST['WP_SALE_AMOUNT'];
			if (isset($_REQUEST['WP_BUYER_NAME'])) $WP_BUYER_NAME = $_REQUEST['WP_BUYER_NAME'];
			if (isset($_REQUEST['WP_SALE_CURRENCY'])) $WP_SALE_CURRENCY = $_REQUEST['WP_SALE_CURRENCY'];
			if (isset($_REQUEST['WP_BUYER_EMAIL'])) $WP_BUYER_EMAIL = $_REQUEST['WP_BUYER_EMAIL'];
			if (isset($_REQUEST['WP_SECURITYKEY'])) $WP_SECURITYKEY = $_REQUEST['WP_SECURITYKEY'];
			
			//Save the payment informations
			// $this->Warriormodel->Ip = $ipaddress;
			// $this->Warriormodel->Userid = $userid;
			// $this->Warriormodel->Productid= $product;
			$this->Warriormodel->TxnId = $WP_TXNID;
			$this->Warriormodel->SaleId = $WP_SALEID;
			$this->Warriormodel->AffiId = $WP_AFFID;
			$this->Warriormodel->TransactionDate = $WP_TRANSACTION_DATE;
			$this->Warriormodel->Action = $WP_ACTION;
			$this->Warriormodel->PayMethod = $WP_PAYMETHOD;
			$this->Warriormodel->SubscribeId = $WP_SUBSCR_ID;
			$this->Warriormodel->SubscribePaynum = $WP_SUBSCR_PAYMENT_NUM;
			$this->Warriormodel->SubscribeAmt = $WP_SUBSCR_PAYMENT_AMOUNT;
			$this->Warriormodel->SubscribeStatus = $WP_SUBSCR_STATUS;
			$this->Warriormodel->SubscriptionTxnId = $WP_SUBSCR_PAYMENT_TXNID;
			$this->Warriormodel->SubscriptionNextDue = $WP_SUBSCR_NEXT_PAYMENT_DATE;
			$this->Warriormodel->ItemName = $WP_ITEM_NAME;
			$this->Warriormodel->ItemNumber = $WP_ITEM_NUMBER;
			$this->Warriormodel->SaleAmount = $WP_SALE_AMOUNT;
			$this->Warriormodel->BuyerFirstName = $WP_BUYER_NAME;
			$this->Warriormodel->SaleCurrency = $WP_SALE_CURRENCY;
			$this->Warriormodel->BuyerEmail = $WP_BUYER_EMAIL;
			$this->Warriormodel->SecretKey = $WP_SECURITYKEY;
			$this->Warriormodel->UpdatedOn = date('Y/m/d H:i:s', time());
			
			$ret = $this->Warriormodel->create(3);
		
			if (!$ret){
				$msg = "Warriorplus - listenerWarriorplus - Create Content Detail - ".$this->Warriormodel->Error;
				echo $msg;
				//Common::sendAdministrativeMail($msg);
				return;
			}
			
			//In case this is the first payment, create an Authorization to register on the system
			if (strtoupper($WP_ACTION) == 'SALE'){
				
				//set the bodyMessage and CreatedBy User
				$bodyEmail = null; 
				
				$profile = $this->ion_auth->where('username', $WP_BUYER_EMAIL)->users()->row(); //pass the code to profile
				//in case the user is new, create it.
				//print_r($profile);exit;
				if (!$profile) {
										
					//configure the products from DealGuardian
					//$oto3 = $this->config->item('oto3', 'dealguardian');
					
					$fe = $this->config->item('fe', 'warrior');
					$feds = $this->config->item('feds', 'warrior');

					$oto1 = $this->config->item('oto1', 'warrior');
					$oto1ds = $this->config->item('oto1ds', 'warrior');

					$oto2 = $this->config->item('oto2', 'warrior');
					$oto2ds = $this->config->item('oto2ds', 'warrior');

					$oto3 = $this->config->item('oto3', 'warrior');
					$oto3ds = $this->config->item('oto3ds', 'warrior');

					$oto4 = $this->config->item('oto4', 'warrior');
					$oto4ds = $this->config->item('oto4ds', 'warrior');
					
					$oto5 = $this->config->item('oto5', 'warrior');
					$oto5ds = $this->config->item('oto5ds', 'warrior');

					//echo $WP_ITEM_NUMBER;
					// echo $WP_ITEM_NUMBER;exit();
					//Define the User Type according to the price of the payment
					if(strpos($fe, $WP_ITEM_NUMBER) !== false) 
					{
						$access = '1';
					}elseif(strpos($feds, $WP_ITEM_NUMBER) !== false) {
						$access = '11';
					}elseif(strpos($oto1, $WP_ITEM_NUMBER) !== false) {
						$access = '2';
					}elseif(strpos($oto1ds, $WP_ITEM_NUMBER) !== false) {
						$access = '21';
					}
					elseif(strpos($oto2, $WP_ITEM_NUMBER) !== false) {
						$access = '3';
					}elseif(strpos($oto2ds, $WP_ITEM_NUMBER) !== false) {
						$access = '31';
					}elseif(strpos($oto3, $WP_ITEM_NUMBER) !== false) {
						$access = '4';
					}elseif(strpos($oto3ds, $WP_ITEM_NUMBER) !== false) {
						$access = '41';
					}elseif(strpos($oto4, $WP_ITEM_NUMBER) !== false) {
						$access = '6';
					}elseif(strpos($oto4ds, $WP_ITEM_NUMBER) !== false) {
						$access = '61';
					}elseif(strpos($oto5, $WP_ITEM_NUMBER) !== false) {
						$access = '7';
					}elseif(strpos($oto5ds, $WP_ITEM_NUMBER) !== false) {
						$access = '71';
					}
					//echo $access;
					$this->ion_auth->register($WP_BUYER_EMAIL, '2iaSin10cI', $WP_BUYER_EMAIL, array('first_name'=>$WP_BUYER_NAME,'product_id'=>$WP_ITEM_NUMBER), array('2'),$access);
					
					$this->selectautoresponder($access,$WP_BUYER_EMAIL,$WP_BUYER_NAME,$WP_ITEM_NUMBER);
				
				//in case the user already exists, update its access
				}else
				{
					//echo 'hii';
					// $access = 1;
					
					//configure the products from warrior
					$fe = $this->config->item('fe', 'warrior');
					$feds = $this->config->item('feds', 'warrior');

					$oto1 = $this->config->item('oto1', 'warrior');
					$oto1ds = $this->config->item('oto1ds', 'warrior');

					$oto2 = $this->config->item('oto2', 'warrior');


					$oto2ds = $this->config->item('oto2ds', 'warrior');

					$oto3 = $this->config->item('oto3', 'warrior');
					$oto3ds = $this->config->item('oto3ds', 'warrior');

					$oto4 = $this->config->item('oto4', 'warrior');
					$oto4ds = $this->config->item('oto4ds', 'warrior');

					$oto5 = $this->config->item('oto5', 'warrior');
					$oto5ds = $this->config->item('oto5ds', 'warrior');
					
					// $oto2ds = $this->config->item('oto2ds', 'warrior');

					
					//Define the User Type according to the price of the payment
					if(strpos($fe, $WP_ITEM_NUMBER) !== false) 
					{
						$access = '1';
					}elseif(strpos($feds, $WP_ITEM_NUMBER) !== false) {
						$access = '11';
					}elseif(strpos($oto1, $WP_ITEM_NUMBER) !== false) {
						$access = '2';
					}elseif(strpos($oto1ds, $WP_ITEM_NUMBER) !== false) {
						$access = '21';
					}
					elseif(strpos($oto2, $WP_ITEM_NUMBER) !== false) {
						$access = '3';
					}elseif(strpos($oto2ds, $WP_ITEM_NUMBER) !== false) {
						$access = '31';
					}elseif(strpos($oto3, $WP_ITEM_NUMBER) !== false) {
						$access = '4';
					}elseif(strpos($oto3ds, $WP_ITEM_NUMBER) !== false) {
						$access = '41';
					}elseif(strpos($oto4, $WP_ITEM_NUMBER) !== false) {
						$access = '6';
					}elseif(strpos($oto4ds, $WP_ITEM_NUMBER) !== false) {
						$access = '61';
					}elseif(strpos($oto5, $WP_ITEM_NUMBER) !== false) {
						$access = '7';
					}elseif(strpos($oto5ds, $WP_ITEM_NUMBER) !== false) {
						$access = '71';
					}
					
					$pos = strpos(','.$profile->access, ','.$access);

					//var_dump($pos);
					
					if($pos === false)
					{
						$profile->access .= ','.$access;						
						$data = '';	
						//print_r($profile->access);exit;
						//print_r($this->Warriormodel->ItemNumber);exit();
						//update user
						$this->Usermodel->updateUserAccess($profile->id, $profile->access,$this->Warriormodel->ItemNumber);
				
						$this->selectautoresponder($access,$WP_BUYER_EMAIL,$WP_BUYER_NAME,$WP_ITEM_NUMBER);

						$this->sendAccessMail($access,$WP_BUYER_EMAIL,$WP_BUYER_NAME);
						
						
					}else
					{
						$previous_product_id=$profile->product_id;
						if($previous_product_id!=""){
						$p_id= $previous_product_id.','.$this->Warriormodel->ItemNumber;
						}else{
						$p_id=$this->Warriormodel->ItemNumber;}
						// exit();
						$this->Usermodel->updateUserAccess($profile->id, $profile->access,$p_id);
				
						$this->selectautoresponder($access,$WP_BUYER_EMAIL,$WP_BUYER_NAME,$WP_ITEM_NUMBER);
						
						$this->sendAccessMail($access,$WP_BUYER_EMAIL,$WP_BUYER_NAME);
					}
				} 
			}else if(strtoupper($WP_ACTION) == 'REBILL'){
				$msg = "Warriorplus - Rebill - <b>UserID</b>:".$buyer_email;
				//Common::sendAdministrativeMail($msg);
			}else if(strtoupper($WP_ACTION) == 'REFUND'){
				$msg = "Warriorplus - Refunded - <b>UserID</b>:".$buyer_email;
				//Common::sendAdministrativeMail($msg);
			}else if(strtoupper($WP_ACTION) == 'CHARGEBACK'){
				$msg = "Warriorplus - ChargeBack  - <b>UserID</b>:".$buyer_email;
				//Common::sendAdministrativeMail($msg);
			}else if(strtoupper($WP_ACTION) == 'FAILED'){
				$msg = "Warriorplus - Failed  - <b>UserID</b>:".$buyer_email;
				//Common::sendAdministrativeMail($msg);
			}else if(strtoupper($WP_ACTION) == 'CANCELATION'){
				
				$profile = $this->ion_auth->where('username', $buyer_email)->users()->row(); //pass the code to profile
				//in case the user is new, create it.
				if ($profile) {
					//$access = 1;
					
					//configure the products from jvzoo
					$oto3 = $this->config->item('oto3', 'warrior');
					
					//Define the User Type according to the price of the payment
					if(strpos($oto3, $WP_ITEM_NUMBER) !== false) {
						$access = '4';
					}
					
					$pos = strpos(','.$profile->access, ','.$access);
					
					if($pos !== false) {
						$newAccess = str_replace(','.$access, '', $profile->access);						
						
						//update user
						$this->Usermodel->updateUserAccess($profile->id, $newAccess);
					}
				}
				
				$msg = "Warriorplus - Cancellation of a Recurring Billing - <b>UserID</b>:".$WP_BUYER_EMAIL;
				//Common::sendAdministrativeMail($msg);
			}
			$name=$WP_BUYER_NAME;
			$lname=$WP_BUYER_NAME;
			$email=$WP_BUYER_EMAIL;
			
			
			echo "IPN received successfully.";
			
		} else {
			$msg = "Warriorplus - listenerWarriorplus- Invalid IPN call - <b>Data</b>:".$raw_post_data;
			//Common::sendAdministrativeMail($msg);
			// IPN invalid, log for manual investigation
			echo "Warriorplus - listenerWarriorplus - Invalid IPN call";
			return;
			//echo "The response from IPN was: <b>" .$res ."</b>";
		}
		return;
	}
	
	/**
*  Autoresponder code
*/
	
	//autoresponder
	function selectautoresponder($access,$contactEmail=null,$firstName=null,$ProductId=null)
	{

            //echo $contactEmail;
            //echo $firstName;exit;
			if($contactEmail !=null && $contactEmail !=''){
				//echo "hii";
				//$this->activecampaign($access,$contactEmail,$firstName,$ProductId);
				//$this->gotoWebinar($contactEmail,$firstName,$lastname);
			    $this->convertkit($access,$contactEmail,$firstName,$ProductId); 
			    //$this->convertkitVenkata($access,$contactEmail,$firstName); 

			}else{
				//echo "bye";
				//$this->activecampaign($access);
				//$this->gotoWebinar();
				$this->convertkit($access); 
			}
			
			
			// 
            
	}
	
	//active compain
	function activecampaign($access,$contactEmail=null,$firstName=null,$ProductId=null)
	{
		
		if($firstName !=null && $firstName !=''){
			$CCustName =$firstName;
		}else{
			$CCustName =$this->Warriormodel->BuyerFirstName;
		}
		if($contactEmail !=null && $contactEmail!=''){
			$CCustEmail =$contactEmail;
		}else{
			$CCustEmail =$this->Warriormodel->BuyerEmail;
		}
		
		//echo $CCustEmail;
		//echo $CCustName;exit;
		if($access=='1'){
			$ListId=831;  // LISTID
			$pname = 'Thriive - Core';
		}else if($access=='11')
		{
			$ListId=832;  // LISTID
			$pname = 'Thriive - lite';

		}else if($access=='2'){
			$ListId=833;  // LISTID
			$pname = 'Thriive - Pro';

		}else if($access=='21'){
			$ListId=834;  // LISTID
			$pname = 'Thriive - Pro Lite';

		}
		else if($access=='3'){
			$ListId=835;  // LISTID
			$pname = 'Thriive - Gold';

		}
		else if($access=='31'){
			$ListId=836;  // LISTID
			$pname = 'Thriive - Gold Lite';		
		}else if($access=='4'){
			$ListId=837;  // LISTID
			$pname = 'Thriive - Instant Traffic';

		}else if($access=='41'){
			$ListId=838;  // LISTID
			$pname = 'Thriive - Instant Traffic Lite';

		}else if($access=='6'){
			$ListId=839;  // LISTID
			$pname = 'Thriive - Agency Unlimited';

		}else if($access=='61'){
			$ListId=840;  // LISTID
			$pname = 'Thriive - Agency 1K';

		}
		else if($access=='7'){
			$ListId=841;  // LISTID
			$pname = 'Thriive - 1K Week V3';

		}
		else if($access=='71'){
			$ListId=842;  // LISTID
			$pname = 'Thriive - 1k Week 4';
		}
		//echo $a;exit;
	    $AppUrl='https://engageleads.api-us1.com';   //API URL
		$apikey ='edb44fd56a36641c0867a118c808c4e75e6c94859bcdbb8d91ee7c35561b106baf7d22c6'; //API KEY 
		
		$f=1;		
		//echo $c;
		//echo $d;
		   try{
			
			$url=$AppUrl;
			$AppKey=$apikey;
			$name=$CCustName;
			$email=$CCustEmail;	
			$ListId=$ListId;
			//$Listname=param5;
			
			$params = array(

			// the API Key can be found on the "Your Settings" page under the "API" tab.
			// replace this with your API Key
			'api_key'      => $AppKey,

			// this is the action that adds a contact
			'api_action'   => 'contact_add',

			// define the type of output you wish to get back
			// possible values:
			// - 'xml'  :      you have to write your own XML parser
			// - 'json' :      data is returned in JSON format and can be decoded with
			//                 json_decode() function (included in PHP since 5.2.0)
			// - 'serialize' : data is returned in a serialized format and can be decoded with
			//                 a native unserialize() function
			'api_output'   => 'serialize',
		);

		// here we define the data we are posting in order to perform an update
		$post = array(
			'email'                    => $email,
			'first_name'               => $name,
			'last_name'                => '',
			'phone'                    => '',
			'orgname'                  => '',
			'tags'                     => $pname,
			'ip4'                      =>$_SERVER['REMOTE_ADDR'],

			// any custom fields
			//'field[345,0]'           => 'field value', // where 345 is the field ID
			//'field[%PERS_1%,0]'      => 'field value', // using the personalization tag instead (make sure to encode the key)

			// assign to lists:
			'p['.$ListId.']'                   => $ListId, // example list ID (REPLACE '123' WITH ACTUAL LIST ID, IE: p[5] = 5)
			'status['.$ListId.']'              => 1, // 1: active, 2: unsubscribed (REPLACE '123' WITH ACTUAL LIST ID, IE: status[5] = 1)
			//'form'          => 1001, // Subscription Form ID, to inherit those redirection settings
			//'noresponders[123]'      => 1, // uncomment to set "do not send any future responders"
			//'sdate[123]'             => '2009-12-07 06:00:00', // Subscribe date for particular list - leave out to use current date/time
			// use the folowing only if status=1
			'instantresponders['.$ListId.']' => 1, // set to 0 to if you don't want to sent instant autoresponders
			//'lastmessage[123]'       => 1, // uncomment to set "send the last broadcast campaign"

			//'p[]'                    => 345, // some additional lists?
			//'status[345]'            => 1, // some additional lists?
		);
		//print_r($params);
		//print_r($post);
		// This section takes the input fields and converts them to the proper format
		$query = "";
		foreach( $params as $key => $value ) $query .= $key . '=' . urlencode($value) . '&';
		$query = rtrim($query, '& ');

		// This section takes the input data and converts it to the proper format
		$data = "";
		foreach( $post as $key => $value ) $data .= $key . '=' . urlencode($value) . '&';
		$data = rtrim($data, '& ');

		// clean up the url
		$url = rtrim($url, '/ ');
		// This sample code uses the CURL library for php to establish a connection,
		// submit your request, and show (print out) the response.

		if ( !function_exists('curl_init') ) die('CURL not supported. (introduced in PHP 4.0.2)');

		// If JSON is used, check if json_decode is present (PHP 5.2.0+)
		if ( $params['api_output'] == 'json' && !function_exists('json_decode') ) {
			die('JSON not supported. (introduced in PHP 5.2.0)');
		}

		// define a final API request - GET
		$api = $url . '/admin/api.php?' . $query;

		$request = curl_init($api); // initiate curl object
		curl_setopt($request, CURLOPT_HEADER, 0); // set to 0 to eliminate header info from response
		curl_setopt($request, CURLOPT_RETURNTRANSFER, 1); // Returns response data instead of TRUE(1)
		curl_setopt($request, CURLOPT_POSTFIELDS, $data); // use HTTP POST to send form data
		curl_setopt($request, CURLOPT_SSL_VERIFYPEER, FALSE); // uncomment if you get no gateway response and are using HTTPS
		curl_setopt($request, CURLOPT_FOLLOWLOCATION, true);

		$response = (string)curl_exec($request); // execute curl post and store results in $response

		// additional options may be required depending upon your server configuration
		// you can find documentation on curl options at http://www.php.net/curl_setopt
		curl_close($request); // close curl object

		if ( !$response ) {
			die('Nothing was returned. Do you have a connection to Email Marketing server?');
		}

		// This line takes the response and breaks it into an array using:
		// JSON decoder
		//$result = json_decode($response);
		// unserializer
		$result = unserialize($response);
		// XML parser...
		// ...

		// Result info that is always returned
		//echo 'Result: ' . ( $result['result_code'] ? 'SUCCESS' : 'FAILED' ) . '<br />';
		//echo 'Message: ' . $result['result_message'] . '<br />';
		if($result['result_code']==0){
			
			echo json_encode(array('error'=>41, 'message'=>$result['result_message']));
		}else{
			
			echo json_encode(array('success'=>1));
		}

						
					//exit;
		}
		catch(Exception $e){
					echo json_encode(array('error'=>41, 'message'=>'Error subscribing on Active Campaign. '. $e->getMessage()));
					exit;
					
		}
	

	}
		
	//mailer Goto Webinar
	function gotoWebinar($contactEmail=null,$firstName=null,$lastname=null){
			

        $organizerkey='8222128548627999238';  //organizerkey
		$accessToken ='XHURzMhxwnT8MO1vMiF5yHuKQUrV'; //accessToken
		$webinarkey='1175251879087152129'; //webinarkey			
		
		if($contactEmail !=null && $contactEmail !=''){
			$data = array(
				  "firstName"=> $firstName,
				  "lastName"=>$lastname,
				  "email"=> $contactEmail
				);
		}else{
			$data = array(
				  "firstName"=> $this->Jvzoolistenermodel->CCustName,
				  "lastName"=>$this->Jvzoolistenermodel->CCustName,
				  "email"=> $this->Jvzoolistenermodel->CCustEmail
				);
		}
		
		
		//print_r($data);
		//exit;

		$gotoWebinar = new GotoWebinar();
		$register = $gotoWebinar->SubmitGotoWebinar($data, $organizerkey, $webinarkey, $accessToken);
		//$test = json_decode($register);
		//print_r($register);
		//exit;
		
		if ($register === false){
			echo json_encode(array('error'=>41, 'message'=>'Error subscribing on GoToWebinar.'));
			// exit;
		}else{
			$pos = strpos($register, '{"joinUrl"');
			$pos1 = strpos($register, '{"registrantKey"');
			if ($pos === false && $pos1 === false) {
				echo json_encode(array('error'=>42, 'message'=>'Error subscribing on GoToWebinar.'));
				// exit;
			}else{
				if ($pos) $register = substr($register, $pos);
				if ($pos1) $register = substr($register, $pos1);
				
				$result = json_decode($register);
				//print_r($result);exit;
				echo json_encode(array('success'=>1));
				//exit; 
			}
		}
	
	}
	//mailer converkit
	function convertkit($access,$contactEmail=null,$firstName=null,$ProductId=null)
	{
	
		if($firstName !=null && $firstName !=''){
			$CCustName =$firstName;
		}else{
			$CCustName =$this->Warriormodel->BuyerFirstName;
		}
		if($contactEmail !=null && $contactEmail!=''){
			$CCustEmail =$contactEmail;
		}else{
			$CCustEmail =$this->Warriormodel->BuyerEmail;
		}
			
			
		
		$apikey='hfubj_8BEeUxQweJZa1oxw';
		 
	    if($access=='1'){
			$tagId = 1981247;  // LISTID
			$pname = 'Thriive - Core';
		}
		else if($access=='11')
		{
			$tagId = 1981248;  // LISTID
			$pname = 'Thriive - lite';
		}
		else if($access=='2')
		{
			$tagId = 1981250;  // LISTID
			$pname = 'Thriive - Pro';

		}
		else if($access=='21')
		{
			$tagId = 1981252;  // LISTID
			$pname = 'Thriive - Pro Lite';

		}
		else if($access=='3')
		{
			$tagId = 1981253;  // LISTID
			$pname = 'Thriive - Gold';

		}
		else if($access=='31')
		{
			$tagId = 1981255;  // LISTID
			$pname = 'Thriive - Gold Lite';		
		}
		else if($access=='4')
		{
			$tagId = 1981256;  // LISTID
			$pname = 'Thriive - Instant Traffic';

		}
		else if($access=='41')
		{
			$tagId = 1981258;  // LISTID
			$pname = 'Thriive - Instant Traffic Lite';

		}
		else if($access=='6')
		{
			$tagId = 1981259;  // LISTID
			$pname = 'Thriive - Agency Unlimited';

		}else if($access=='61'){
			$tagId = 1981260;  // LISTID
			$pname = 'Thriive - Agency 1K';

		}
		else if($access=='7')
		{
			$tagId = 1981261;  // LISTID
			$pname = 'Thriive - 1K Week V3';

		}
		else if($access=='71')
		{
			$tagId = 1981262;  // LISTID
			$pname = 'Thriive - 1k Week 4';
		}

	    $args = array(
			"api_key"  =>$apikey, 
	        "email"=>$CCustEmail, 
	        "first_name"=>$CCustName,
		);
		
		$api='https://api.convertkit.com/v3/tags/'.$tagId.'/subscribe';
		$request = curl_init($api); // initiate curl object
		curl_setopt($request, CURLOPT_HEADER,'Content-type:  application/json'); // set to 0 to eliminate header info from response
		curl_setopt($request, CURLOPT_RETURNTRANSFER, 1); // Returns response data instead of TRUE(1)
		curl_setopt($request, CURLOPT_POSTFIELDS, $args); // use HTTP POST to send form data
		curl_setopt($request, CURLOPT_SSL_VERIFYPEER, FALSE); // uncomment if you get no gateway response and are using HTTPS
		curl_setopt($request, CURLOPT_FOLLOWLOCATION, true);

		$register = (string)curl_exec($request);
		//print_r($register);
		$arr=json_decode($register);
		//print_r($arr);
		if ($arr === false){
			echo json_encode(array('error'=>41, 'message'=>'Error subscribing on ConvertKit.'));
			exit;
		}else{
			//echo $subscriberId=$arr['subscription']['subscriber']['id'];
			//echo $state=$arr['subscription']['subscriber']['state'];
			echo json_encode(array('success'=>1));
				//exit; 
			}
		
	
	}
	
	//sendmail by mailgun_config
	public function sendAccessMail($access,$WP_BUYER_EMAIL,$WP_BUYER_NAME){
		return  true;
		$data=array();
		if($access=='2' || $access=='21')
		{	
			//echo $access."inside upgrade1";
			
			
						
			//$message = 'Congrats you are successfully Upgraded!!';
			
			if($access=='2')
			{
				$data['product']='Pro';
				
				$subject= $this->config->item('email_upgrade_subject', 'ion_auth');

			}
			else
			{
				
				$data['product']='Pro Lite';
				
				$subject=$this->config->item('email_upgrade_subject_lite', 'ion_auth');

			}
			$message = $this->load->view($this->config->item('email_templates', 'ion_auth').$this->config->item('email_upgrade', 'ion_auth'), $data, true);
							
		}						
		if($access=='3' || $access=='31')
		{	
					
			if($access=='3')
			{
				$data['product']='Gold';
				
				$subject=$this->config->item('email_upgrade2_subject', 'ion_auth');
			}
			else
			{
				$data['product']='Gold Lite';
				
				$subject=$this->config->item('email_upgrade2_subject_lite', 'ion_auth');
			}
			
			$message = $this->load->view($this->config->item('email_templates', 'ion_auth').$this->config->item('email_upgrade2', 'ion_auth'), $data, true);
		}							
		if($access=='4' || $access=='41')
		{

			if($access=='41')
			{
				$data['product']='Instant Traffic Lite';
				
				$subject=$this->config->item('email_upgrade3_subject_lite', 'ion_auth');

			}
			else
			{
				$data['product']='Instant Traffic';
				
				$subject=$this->config->item('email_upgrade3_subject', 'ion_auth');

			}
			
			$message = $this->load->view($this->config->item('email_templates', 'ion_auth').$this->config->item('email_upgrade3', 'ion_auth'), $data, true);
			
		} 
		if($access=='6' || $access=='61')
		{

			if($access=='61')
			{
				$data['product']='Agency 1K';
				
				$subject=$this->config->item('email_upgrade4_subject_lite', 'ion_auth');

			}
			else
			{
				$data['product']='Agency Unlimited';
				
				$subject=$this->config->item('email_upgrade4_subject', 'ion_auth');

			}
			
			$message = $this->load->view($this->config->item('email_templates', 'ion_auth').$this->config->item('email_upgrade4', 'ion_auth'), $data, true);
			
		}
		if($access=='7' || $access=='71')
		{

			if($access=='71')
			{
				$data['product']='1k Week 4';
				
				$subject=$this->config->item('email_upgrade5_subject_lite', 'ion_auth');

			}
			else
			{
				$data['product']='1k Week V3';
				
				$subject=$this->config->item('email_upgrade5_subject', 'ion_auth');

			}
			
			$message = $this->load->view($this->config->item('email_templates', 'ion_auth').$this->config->item('email_upgrade5', 'ion_auth'), $data, true);
		}
		
		$key=$this->config->item('key', 'mailgun');
		$domain=$this->config->item('domain', 'mailgun');
		$to=$WP_BUYER_NAME.' <'.$WP_BUYER_EMAIL.'>';
		$from=$this->config->item('site_title', 'ion_auth').' <'.$this->config->item('admin_email', 'ion_auth').'>';
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		curl_setopt($ch, CURLOPT_USERPWD, 'api:'.$key);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
		curl_setopt($ch, CURLOPT_URL, 
          'https://api.mailgun.net/v3/'.$domain.'/messages');
		curl_setopt($ch, CURLOPT_POSTFIELDS, 
            array('from' => $from,
                  'to' => $to,
                  'subject' =>$subject,
                  'html' => $message));
      
      $result = curl_exec($ch);
      curl_close($ch);
      return $result;
    }

}
