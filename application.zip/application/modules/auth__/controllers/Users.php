<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Users extends CI_Controller 
{

	function __construct()
	{
		parent::__construct();
		$this->load->library('ion_auth');
		$this->load->helper('url');
		$this->load->helper('form');
		$this->load->library('form_validation');
		$this->load->model('Usermodel');
		$this->load->model('Ion_auth_model');
		$this->lang->load('auth');
		$this->load->helper('language');
		$this->lang->load('page');		
		$this->load->config('warriror_config');
		if(!$this->ion_auth->logged_in()) {
				
				redirect('/login');
			
			} 
		
		
	}

	
	public function index($page='', $search = null ) {
	
		if ($page == ''){
			$page = 0;
		}else{
			$page = $page - 1; 
		}
		$user = $this->ion_auth->user()->row();
		$userID = $user->id;
		$itemsPerPage = 10;
		
		if (isset($_REQUEST['search']) && !is_null($_REQUEST['search'])){

			$this->data['users'] = $this->Usermodel->getSearchUser($_REQUEST['search'],$itemsPerPage,$page);
		    $total_row =$this->Usermodel->record_search_count_all($_REQUEST['search']);
		    // echo "string";exit;

		}
		else if( $userID ==1)
		{
			$this->data['users'] = $this->Usermodel->getAllUsers($itemsPerPage,$page);
			$total_row =$this->Usermodel->user_record_count_all();
			
		}
		else{
			
			$this->data['users'] = $this->Usermodel->getAll($itemsPerPage,$page);
		  $total_row =$this->Usermodel->user_record_count();
			
		}
	  
	
	  //pagination
		  $this->load->library('pagination');
		  $config['base_url'] =base_url() . "index.php/users/index/";
		  //$total_row =$this->Usermodel->user_record_count();
		  $config['total_rows'] = $total_row;
		  $config["per_page"] = $itemsPerPage;  
		  $config['use_page_numbers'] = TRUE;
		  $config['num_links'] = 2;
		 $config['cur_tag_open'] = '&nbsp;<li class="page-item active"><a class="page-link">';
		  $config['cur_tag_close'] = '</a></li>';
		  $config['first_link'] = 'First';
		  $config['last_link'] = 'Last';
		  $config['next_link'] = '>>';
		  $config['prev_link'] = '<<';
		
		  $this->pagination->initialize($config); 
		  if($this->uri->segment(3)){
			$page = ($this->uri->segment(3)) ;
			}
			else{
			$page = 1;
			} 
			
		$str_links = $this->pagination->create_links();
		$this->data["links"] = explode('&nbsp;',$str_links );		
		 //END - config the pagination 
		$this->data['row_count'] = $total_row;
		$this->data['ActiveTab'] = 'users';
		$this->load->view('users/users', $this->data);
	
	}
	
	
	
	/*
	
		creates a new user account
	
	*/
	
	public function create() {
	
		$this->form_validation->set_rules('firstname', 'First name', 'required');
		$this->form_validation->set_rules('lastname', 'Last name', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
		$this->form_validation->set_rules('password', 'Password', 'required');
		$this->form_validation->set_rules('access[]', 'Access', 'required');
	
		if ($this->form_validation->run() == FALSE) {
			
			//all did not go well
			$return = array();
			
			$temp = array();
			$temp['header'] = $this->lang->line('users_create_error1_heading');
			$temp['content'] = $this->lang->line('users_create_error1_message').validation_errors();
			
			$return['responseCode'] = 0;
			$return['responseHTML'] = $this->load->view('partials/error', array('data'=>$temp), true);
			
			die( json_encode( $return ) );
		
		} else {
		 
			$fe = $this->config->item('fe', 'warrior');
			$feds = $this->config->item('feds', 'warrior');

			$oto1 = $this->config->item('oto1', 'warrior');
			$oto1ds = $this->config->item('oto1ds', 'warrior');

			$oto2 = $this->config->item('oto2', 'warrior');
			$oto2ds = $this->config->item('oto2ds', 'warrior');

			$oto3 = $this->config->item('oto3', 'warrior');
			$oto3ds = $this->config->item('oto3ds', 'warrior');

			$oto4 = $this->config->item('oto4', 'warrior');
			$oto4ds = $this->config->item('oto4ds', 'warrior');

			$oto5 = $this->config->item('oto5', 'warrior');
			$oto5ds = $this->config->item('oto5ds', 'warrior');
			//print_r($_POST['access']);exit;
			$access='';
			if(in_array($fe, $_POST['access'])){
				if(empty($access)){
					$access .= '1';
				}else{
					$access .= ',1';
				}
			}
			if(in_array($feds, $_POST['access'])){
				if(empty($access)){
					$access .= '11';
				}else{
					$access .= ',11';
				}	
			}
			if(in_array($oto1, $_POST['access'])){
				$access .= ',2';	
			}
			if(in_array($oto1ds, $_POST['access'])){
				$access .= ',21';	
			}
			if(in_array($oto2, $_POST['access'])){
				$access .= ',3';	
			}
			if(in_array($oto2ds, $_POST['access'])){
				$access .= ',31';	
			}
			if(in_array($oto3, $_POST['access'])){
				$access .= ',4';	
			}
			if(in_array($oto3ds, $_POST['access'])){
				$access .= ',41';	
			}
			if(in_array($oto4, $_POST['access'])){
				$access .= ',6';	
			}
			if(in_array($oto4ds, $_POST['access'])){
				$access .= ',61';	
			}
			if(in_array($oto5, $_POST['access'])){
				$access .= ',7';	
			}
			if(in_array($oto5ds, $_POST['access'])){
				$access .= ',71';	
			}
			//make sure the email address is allowed
			if( $this->ion_auth->email_check($_POST['email']) ) {
			
				//all did not go well
				$return = array();
				
				$temp = array();
				$temp['header'] = $this->lang->line('users_create_error1_heading');
				$temp['content'] = $this->lang->line('users_create_error2_message');
				
				$return['responseCode'] = 0;
				$return['responseHTML'] = $this->load->view('partials/error', array('data'=>$temp), true);
				
				die( json_encode( $return ) );
			
			}
			$user = $this->ion_auth->user()->row();
			$userID = $user->id;
			
			//create the account
			
			if($userID == '1'  || $userID=='3' || $userID=='19') {//new account is admin
				
				//email activation?
				if( isset($_POST['notify']) && $_POST['notify'] == 'yes' ) {
				
					$this->ion_auth->registerManually($_POST['email'], $_POST['password'], $_POST['email'], array('first_name'=>$_POST['firstname'], 'last_name'=>$_POST['lastname']), array('1'), true, $access);
				
				} else {
				
					$this->ion_auth->registerManually($_POST['email'], $_POST['password'], $_POST['email'], array('first_name'=>$_POST['firstname'], 'last_name'=>$_POST['lastname']), array('1'), false, $access);
				
				}
			
			
			} 
			
			//all good then
			$return = array();
			
			//include users in the return as well
			//$return['users'] = $this->load->view('partials/users', array('users'=>$this->Usermodel->getUsersPlusSites()), true);
			
			$temp = array();
			$temp['header'] = $this->lang->line('users_create_success_heading');
			$temp['content'] = $this->lang->line('users_create_success_message');
			
			$return['responseCode'] = 1;
			$return['responseHTML'] = $this->load->view('partials/success', array('data'=>$temp), true);
			
			die( json_encode( $return ) );
		
		
	
		}
	}
	
	
	
	/*
	
		updates existing user
		
	*/
	
	public function update() {
		
		$this->form_validation->set_rules('userID', 'User ID', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
		// $this->form_validation->set_rules('password', 'Password', 'required');
		$this->form_validation->set_rules('access[]', 'Access', 'required');
	
		if ($this->form_validation->run() == FALSE) {
			
			//all did not go well
			$return = array();
			
			$temp = array();
			$temp['header'] = $this->lang->line('users_update_error1_heading');
			$temp['content'] = $this->lang->line('users_update_error1_message').validation_errors();
			
			$return['responseCode'] = 0;
			$return['responseHTML'] = $this->load->view('partials/error', array('data'=>$temp), true);
			
			die( json_encode( $return ) );
		
		} else {
			
			$fe = $this->config->item('fe', 'warrior');
			$feds = $this->config->item('feds', 'warrior');

			$oto1 = $this->config->item('oto1', 'warrior');
			$oto1ds = $this->config->item('oto1ds', 'warrior');

			$oto2 = $this->config->item('oto2', 'warrior');
			$oto2ds = $this->config->item('oto2ds', 'warrior');

			$oto3 = $this->config->item('oto3', 'warrior');
			$oto3ds = $this->config->item('oto3ds', 'warrior');

			$oto4 = $this->config->item('oto4', 'warrior');
			$oto4ds = $this->config->item('oto4ds', 'warrior');

			$oto5 = $this->config->item('oto5', 'warrior');
			$oto5ds = $this->config->item('oto5ds', 'warrior');
			//print_r($_POST['access']);exit;
			$access='';
			if(in_array($fe, $_POST['access'])){
				if(empty($access)){
					$access .= '1';
				}else{
					$access .= ',1';
				}
			}
			if(in_array($feds, $_POST['access'])){
				if(empty($access)){
					$access .= '11';
				}else{
					$access .= ',11';
				}	
			}
			if(in_array($oto1, $_POST['access'])){
				$access .= ',2';	
			}
			if(in_array($oto1ds, $_POST['access'])){
				$access .= ',21';	
			}
			if(in_array($oto2, $_POST['access'])){
				$access .= ',3';	
			}
			if(in_array($oto2ds, $_POST['access'])){
				$access .= ',31';	
			}
			if(in_array($oto3, $_POST['access'])){
				$access .= ',4';	
			}
			if(in_array($oto3ds, $_POST['access'])){
				$access .= ',41';	
			}
			if(in_array($oto4, $_POST['access'])){
				$access .= ',6';	
			}
			if(in_array($oto4ds, $_POST['access'])){
				$access .= ',61';	
			}
			if(in_array($oto5, $_POST['access'])){
				$access .= ',7';	
			}
			if(in_array($oto5ds, $_POST['access'])){
				$access .= ',71';	
			}
		
			//make sure the email address is allowed
			
			$user = $this->ion_auth->user($_POST['userID'])->row();
			
			if( $_POST['email'] != $user->email && $this->ion_auth->email_check($_POST['email']) ) {
			
			//if( $_POST['email'] === $user->username || $_POST['email'] === $user->email || $this->ion_auth->identity_check($_POST['email']) === FALSE ) {
			
				//all did not go well
				$return = array();
				
				$temp = array();
				$temp['header'] = $this->lang->line('users_update_error2_heading');
				$temp['content'] = $this->lang->line('users_update_error2_message');
				
				$return['responseCode'] = 0;
				$return['responseHTML'] = $this->load->view('partials/error', array('data'=>$temp), true);
				
				die( json_encode( $return ) );
			
			}
			
			//update the account details

			
			$this->ion_auth_model->update($_POST['userID'], array('email'=>$_POST['email'], 'password'=>$_POST['password'], 'access'=>$access,'first_name'=>$_POST['firstname'],'last_name'=>$_POST['lastname']));
			
			
			//admin?
			
			if( isset($_POST['isAdmin']) && $_POST['isAdmin'] == 'yes' ) {
			
				$this->ion_auth->add_to_group(1, $_POST['userID']);
			
			} else {
			
				$this->ion_auth->remove_from_group(1, $_POST['userID']);
				
			}
			
			//all good then
			$return = array();
						
			$temp = array();
			$temp['header'] = $this->lang->line('users_update_success_heading');
			$temp['content'] = $this->lang->line('users_update_success_message');
			
			$return['responseCode'] = 1;
			$return['responseHTML'] = $this->load->view('partials/success', array('data'=>$temp), true);
			
			die( json_encode( $return ) );
		
		}
		
	}
	
  public function deleteSelectedUsers(){
  
	$ids = (explode( ',', $this->input->get_post('ids')));
 
	$this->checkall['id']=$this->Usermodel->deleteAllUsers($ids);
	
	//$this->data['sites'] = $this->datamodel->all();
  
    //$this->load->view('site/pages',$this->data);
 
	}	
	
	
	/*
	
		perfor a manualy user pw reset email
	
	*/
	
	public function rpw($userID = '') {
	
		if( $userID == '' || $userID == 'undefined' ) {
		
			//error, missing userID
			//all did not go well
			$return = array();
			
			$temp = array();
			$temp['header'] = "Ouch! Something went wrong:";
			$temp['content'] = "Some important data is missing. Please reload this page and try again.";
			
			$return['responseCode'] = 0;
			$return['responseHTML'] = $this->load->view('partials/error', array('data'=>$temp), true);
			
			die( json_encode( $return ) );
			
		
		}
		
		
		//guess all is well :), send email
		
		$user = $this->ion_auth->user($userID)->row();
		
		$forgotten = $this->ion_auth->forgotten_password( $user->email );
		
		if( $forgotten ) {//email sent
		
			$return = array();
						
			$temp = array();
			$temp['header'] = "Hooray!";
			$temp['content'] = "A reset password email was sent to <b>".$user->email."</b>.";
			
			$return['responseCode'] = 1;
			$return['responseHTML'] = $this->load->view('partials/success', array('data'=>$temp), true);
			
			die( json_encode( $return ) );
		
		} else {//email not sent
		
			$return = array();
			
			$temp = array();
			$temp['header'] = "Ouch! Something went wrong:";
			$temp['content'] = "Something went wrong when trying to sent the password reset email, please see the errors below:<br>".$this->ion_auth->errors();
			
			$return['responseCode'] = 0;
			$return['responseHTML'] = $this->load->view('partials/error', array('data'=>$temp), true);
			
			die( json_encode( $return ) );
		
		}
	
	}
	public function resetUser()
	{
		$userId = $_POST['userID'];
		$email = $_POST['email'];
        if(    $userId == '' || $userId =='undefined' ){
            
            //echo "UserId is Missing";
            
        $return = array();
            
            $temp = array();
            $temp['header'] = $this->lang->line('users_userAjax_error1_heading');
            $temp['content'] = $this->lang->line('users_userAjax_error1_message');
            
            $return['responseCode'] = 0;
            $return['responseHTML'] = $this->load->view('partials/error', array('data'=>$temp), true);
            
            die( json_encode( $return ) );
        
        }
		$password= md5(uniqid(rand(0,5), true));
		$password = (strlen($password) > 8) ? substr($password,0,7): $password;		
        $reset = $this->ion_auth_model->resetUser($userId , $email , $password);
		if($reset)
		{
			$return = array();
						
			$temp = array();
			$temp['header'] = "";
			$temp['content'] = $password;
			
			$return['responseCode'] = 1;
			$return['responseHTML'] = $temp['content'];
			
			die( json_encode( $return ) );			
			
		}
	
		
	}


	public function deleteUser()
	{
		 $userid=$_POST['id'];
 	 	 $this->UserId['id']=$this->Usermodel->deleteUser($userid);
 	}
	
	
	/*
	
		deletes an entire user account, incl sites and other data
	
	*/
	
	public function delete($userID = '') {
		$user = $this->Usermodel->getUsersPlusSites($userID);
		
		/*print("<pre>");
		print_r($user[0]['userData']->subdomain);
		print_r($user[0]);
		print("</pre>");
		exit;*/
		
		//delete subdomain and sites
		if (isset($user[0])){
			if (!empty($user[0]['userData']->subdomain)){
				//delete sites published on the server
				$this->load->helper('file');
				
				foreach ($user[0]['sites'] as $sites){
					$folder = $this->config->item('ftpPath', 'subdomain').'/'.$user[0]['userData']->subdomain.'/'.$sites["siteData"]->sites_name;
					
					if (file_exists($folder)) {
						//print($folder);
						delete_files($folder);
					}
				}
				
				//delete subdomain
				//$this->subdomainmodel->delete_subdomain( $userID );
			}
		}
		
		//start by deleting all sites for this user
		//$this->sitemodel->deleteAllFor( $userID );
		
		//exit;
		//now delete the user account
		
		if( $this->ion_auth->delete_user( $userID ) ) {
			
			//deleted
			$this->session->set_flashdata('success', "The user account has been deleted.");
			
			redirect('/users/', 'refresh');
		
		} else {
		
			//not deleted
			$this->session->set_flashdata('error', "The user's sites were deleted, but we couldn't remove the user account. Please reload and try again.");
			
			redirect('/users/', 'refresh');
		
		}
	
	} 
	
	
	
	/*
	
		update account first name and last name
	
	*/
	
	public function uaccount() {
	
		$this->form_validation->set_rules('userID', 'User ID', 'required');
		$this->form_validation->set_rules('firstname', 'First name', 'required');
		$this->form_validation->set_rules('lastname', 'Last name', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
		$this->form_validation->set_rules('password', 'Password', 'required');
		
		if ($this->form_validation->run() == FALSE) {
			
			//all did not go well
			$return = array();
			
			$temp = array();
			$temp['header'] = "Ouch! Something went wrong:";
			$temp['content'] = "Something went wrong when trying to update your details, please see the errors below:<br><br>".validation_errors();
			
			$return['responseCode'] = 0;
			$return['responseHTML'] = $this->load->view('partials/error', array('data'=>$temp), true);
			
			die( json_encode( $return ) );
		
		} else {
		
			//all well, update user details
			
			$data = array(
				'first_name' => $_POST['firstname'],
				'last_name' => $_POST['lastname'],
				'email' => $_POST['email'],
				'password' => $_POST['password']
			);
			
			if( $this->ion_auth->update($_POST['userID'], $data) ) {
			
				//saved ok
				$return = array();
							
				$temp = array();
				$temp['header'] = "Hooray!";
				$temp['content'] = "Your account details were updated successfully and it will be correctly shown once you reload the page.";
				
				$return['responseCode'] = 1;
				$return['responseHTML'] = $this->load->view('partials/success', array('data'=>$temp), true);
				
				die( json_encode( $return ) );
			
			} else {
			
				//not saved
				//all did not go well
				$return = array();
				
				$temp = array();
				$temp['header'] = "Ouch! Something went wrong:";
				$temp['content'] = "We weren't able to save your details just now. Please reload the page and try again.";
				
				$return['responseCode'] = 0;
				$return['responseHTML'] = $this->load->view('partials/error', array('data'=>$temp), true);
				
				die( json_encode( $return ) );
			
			}
		
		}
	
	}
	
	//edituser
	public function editUser($userId =''){
        
    
        if(    $userId == '' || $userId =='undefined' ){
            
            //echo "UserId is Missing";
            
        $return = array();
            
            $temp = array();
            $temp['header'] = $this->lang->line('users_userAjax_error1_heading');
            $temp['content'] = $this->lang->line('users_userAjax_error1_message');
            
            $return['responseCode'] = 0;
            $return['responseHTML'] = $this->load->view('partials/error', array('data'=>$temp), true);
            
            die( json_encode( $return ) );
        
        }
        
        $userData = $this->Usermodel->getUser($userId);
        
        if( $userData == false ) {
        
            //all did not go well
            $return = array();
            
            $temp = array();
            $temp['header'] = $this->lang->line('users_userAjax_error2_heading');
            $temp['content'] = $this->lang->line('users_userAjax_error2_message');
            
            $return['responseCode'] = 0;
            $return['responseHTML'] = $this->load->view('partials/error', array('data'=>$temp), true);
            
            echo json_encode( $return );
        
        } else {
            
            //all went well
            $return = array();
            
            $return['responseCode'] = 1;
            $return['responseData'] = $userData;
            
            //print_r($return);
            //exit;
            
            echo json_encode( $return );        
        
        }
    
    
    
    
    }
	
	/*
		
		updates an account's login credential
		
	*/
	
	public function ulogin() {
	
		$this->form_validation->set_rules('userID', 'User ID', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
		$this->form_validation->set_rules('password', 'Password', 'required');
		
		
		if ($this->form_validation->run() == FALSE) {
			
			//all did not go well
			$return = array();
			
			$temp = array();
			$temp['header'] = "Ouch! Something went wrong:";
			$temp['content'] = "Something went wrong when trying to update your details, please see the errors below:<br><br>".validation_errors();
			
			$return['responseCode'] = 0;
			$return['responseHTML'] = $this->load->view('partials/error', array('data'=>$temp), true);
			
			die( json_encode( $return ) );
		
		} else {
		
			//all well, update user details
			
			$data = array(
				'email' => $_POST['email'],
				'password' => $_POST['password']
			);
			
			if( $this->ion_auth->update($_POST['userID'], $data) ) {
			
				//saved ok
				$return = array();
							
				$temp = array();
				$temp['header'] = "Hooray!";
				$temp['content'] = "Your account details were updated successfully and it will be correctly shown once you reload the page.";
				
				$return['responseCode'] = 1;
				$return['responseHTML'] = $this->load->view('partials/success', array('data'=>$temp), true);
				
				die( json_encode( $return ) );
			
			} else {
			
				//not saved
				//all did not go well
				$return = array();
				
				$temp = array();
				$temp['header'] = "Ouch! Something went wrong:";
				$temp['content'] = "We weren't able to save your details just now. Please reload the page and try again.";
				
				$return['responseCode'] = 0;
				$return['responseHTML'] = $this->load->view('partials/error', array('data'=>$temp), true);
				
				die( json_encode( $return ) );
			
			}
		
		}
	
	}
	
	
	
	
}

/* End of file users.php */
/* Location: ./application/controllers/users.php */