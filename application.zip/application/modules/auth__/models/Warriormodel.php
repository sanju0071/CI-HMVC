<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Warriormodel extends CI_Model {

		private $sandbox = false;
		//attributes
        public $Userid;
        public $WarriorListener_id;
        public $Ip;
        public $Productid;
        public $TxnId;
        public $SaleId;
        public $AffiId;
        public $Action;
        public $TransactionDate;
        public $PayMethod;
        public $SubscribeId;
        public $SubscribePaynum;
        public $SubscribeAmt;
        public $SubscribeStatus;
        public $SubscriptionTxnId;
        public $SubscriptionNextDue;
        public $ItemName;
        public $ItemNumber;
        public $SaleAmount;
        public $BuyerFirstName;
        public $SaleCurrency;
        public $BuyerEmail;
        public $SecretKey;
        public $UpdatedOn;
		
		public $Error;
	
    function __construct()
    {
        parent::__construct();
        
        $this->load->database();
        $this->load->library('session');
        $this->load->library('ion_auth');
    }


    public function insertValue($value){
       $data = array(
            'content' => $value
        );
        $this->db->insert('warriorlistener', $data);
    }
    
    /**
	 * create
	 *
	 * @return bool
	 * @author João
	 **/
	public function create($stage)
    {
        if ($stage == 1){
            $data = array(
            'receivedon' => $this->ReceivedOn
        );
            
        $newSiteID = false;
        try{
            $this->db->insert('warriorlistener', $data);
            $newSiteID = $this->db->insert_id();
        }
        catch (Exception $e){
            $this->Error = $e->getMessage();
                $newSiteID = false;
            }
        return $newSiteID;
            
        }elseif ($stage == 2){
            $data = array(
            'content' => $this->Content
        );
        
        $updated = false;
        try{
            $this->db->where('warriorlistener_id', $this->WarriorListener_id);
            $this->db->update('warriorlistener', $data);
            
            $updated = true;
        }
        catch (Exception $e){
            $this->Error = $e->getMessage();
                $updated = false;
            }
        return $updated;
            
        }elseif ($stage == 3){
            $data = array(
            'ip'=>$this->Ip,
            'userid'=> $this->Userid,
            'productid'=> $this->Productid,
            'WP_TXNID'=> $this->TxnId,
            'WP_SALEID'=> $this->SaleId,
            'WP_TRANSACTION_DATE'=> $this->TransactionDate,
            'WP_ACTION'=> $this->Action,
            'WP_PAYMETHOD'=> $this->PayMethod,
            'WP_SUBSCR_ID'=> $this->SubscribeId,
            'WP_SUBSCR_STATUS'=> $this->SubscribeStatus,
            'WP_AFFID'=> $this->AffiId,
            'WP_SUBSCR_PAYMENT_NUM'=> $this->SubscribePaynum,
            'WP_SUBSCR_PAYMENT_AMOUNT'=> $this->SubscribeAmt,
            'WP_SUBSCR_PAYMENT_TXNID'=> $this->SubscriptionTxnId,
            'WP_SUBSCR_NEXT_PAYMENT_DATE'=> $this->SubscriptionNextDue,
            'WP_ITEM_NAME'=> $this->ItemName,
            'WP_ITEM_NUMBER'=> $this->ItemNumber,
            'WP_SALE_AMOUNT'=> $this->SaleAmount,
            'WP_BUYER_NAME'=> $this->BuyerFirstName,
            'WP_SALE_CURRENCY'=> $this->SaleCurrency,
            'WP_BUYER_EMAIL'=> $this->BuyerEmail,
            'secret_key'=> $this->SecretKey,
            'updatedon'=> $this->UpdatedOn
        );
        
        //print_r($data);
        //exit;
        
        $updated = false;
        try{
            $this->db->where('warriorlistener_id', $this->WarriorListener_id);
            $update = $this->db->update('warriorlistener', $data);
            //var_dump($update);
            //exit;
            $updated = true;
        }
        catch (Exception $e){
            $this->Error = $e->getMessage();
                $updated = false;
            }
            //var_dump($updated);
            //exit;
        return $updated;
        }
    }
}