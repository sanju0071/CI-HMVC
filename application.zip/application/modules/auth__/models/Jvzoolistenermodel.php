<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Jvzoolistenermodel extends CI_Model {

		private $sandbox = false;
		
		//attributes
		public $JvZooLientener_id;
		public $ReceivedOn;
		public $Content;
		public $CCustName;
		public $CCustState;
		public $CCustCc;
		public $CCustEmail;
		public $CProdItem;
		public $CProdTitle;
		public $CProdType;
		public $CTransaction;
		public $CTransAffiliate;
		public $CTransAmount;
		public $CTransPaymentMethod;
		public $CTransVendor;
		public $CTransReceipt;
		public $CUpsellReceipt;
		public $CAffitID;
		public $CVendThru;
		public $CVerify;
		public $CTransTime;
		public $UpdatedOn;
		
		public $Error;
	
    function __construct()
    {
        parent::__construct();
        
        $this->load->database();
        $this->load->library('session');
        $this->load->library('ion_auth');
    }
    
    /**
	 * create
	 *
	 * @return bool
	 * @author Jo�o
	 **/
	public function create($stage)
	{
		if ($stage == 1){
			$data = array(
    		'receivedon' => $this->ReceivedOn
    	);
    		
    	$newSiteID = false;
    	try{
    		$this->db->insert('jvzoolistener', $data);
    		$newSiteID = $this->db->insert_id();
    	}
    	catch (Exception $e){
    		$this->Error = $e->getMessage();
				$newSiteID = false;
			}
    	return $newSiteID;
			
		}elseif ($stage == 2){
			$data = array(
    		'content' => $this->Content
    	);
    	
    	$updated = false;
    	try{
    		$this->db->where('jvzoolistener_id', $this->JvZooLientener_id);
    		$this->db->update('jvzoolistener', $data);
    		
    		$updated = true;
    	}
    	catch (Exception $e){
    		$this->Error = $e->getMessage();
				$updated = false;
			}
    	return $updated;
			
		}elseif ($stage == 3){
			$data = array(
    		'ccustname' 					=> $this->CCustName,
    		'ccuststate' 					=> $this->CCustState,
    		'ccustcc' 						=> $this->CCustCc,
    		'ccustemail' 					=> $this->CCustEmail,
    		'cproditem' 					=> $this->CProdItem,
    		'cprodtitle' 					=> $this->CProdTitle,
    		'cprodtype' 					=> $this->CProdType,
    		'ctransaction' 				=> $this->CTransaction,
    		'ctransaffiliate' 		=> $this->CTransAffiliate,
    		'ctransamount' 				=> $this->CTransAmount,
    		'ctranspaymentmethod' => $this->CTransPaymentMethod,
    		'ctransvendor' 				=> $this->CTransVendor,
    		'cupsellreceipt' 			=> $this->CUpsellReceipt,
    		'caffitid' 						=> $this->CAffitID,
    		'cvendthru' 					=> $this->CVendThru,
    		'cverify' 						=> $this->CVerify,
    		'ctranstime' 					=> $this->CTransTime,
    		'updatedon' 					=> $this->UpdatedOn,
    	);
    	
    	//print_r($data);
    	//exit;
    	
    	$updated = false;
    	try{
    		$this->db->where('jvzoolistener_id', $this->JvZooLientener_id);
    		$update = $this->db->update('jvzoolistener', $data);
    		//var_dump($update);
    		//exit;
    		$updated = true;
    	}
    	catch (Exception $e){
    		$this->Error = $e->getMessage();
				$updated = false;
			}
			//var_dump($updated);
			//exit;
    	return $updated;
		}
	}
}