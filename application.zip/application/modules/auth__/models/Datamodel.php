<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Datamodel extends CI_Model {
    function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    /*
        check record exists or not
    */
    public function checkExit($table,$where)
    {
        // print_r($where);exit;
        $this->db->where($where);
        $this->db->from($table);
        $query = $this->db->get();

        // echo $this->db->last_query();exit;
        return $query->num_rows();
    }    


    /* 
        fetch table data from given condition
    */
    public function fetchTableData($table,$where = array(),$select = '',$where_in = array(),$where_in_column='',$whereDate = '')
    {
        // print_r($where);
        if(!empty($where))
        {
            $this->db->where($where);
        }

        if(!empty($select))
        {
            $this->db->select($select);
        }

        if(!empty($where_in))
        {
            $this->db->where_in($where_in_column,$where_in);
        }


        if(!empty($whereDate))
        {
            $this->db->where($whereDate);
        }

        $this->db->from($table);
        $query = $this->db->get();
        $res = $query->result();
        $result=array();
        foreach($res as $r)
        {
            $temp=array();
            $temp['Data']=$r;
            $result[]=$temp;
        }

        // echo $this->db->last_query();exit; 
        return $result;
    }


    /*
        insert table data to table 

    */
    public function insertTable($table,$data)
    {
        $this->db->insert($table,$data);

        return $this->db->insert_id();
    }


    /*
        ip[date the table
    */
    public function updateTable($table,$where,$data)
    {
        $this->db->where($where);
        $this->db->update($table,$data);
    }


    /*
        Increment The value
    */

    public function increateTable($table,$where,$data)
    {
         $this->db->where($where);
         $this->db->set($data, "$data+1", FALSE);   
         $this->db->update($table);
    }
    

    /*
        delete the database data
    */
    public function deleteTableData($table,$where)
    {
        $this->db->where($where);
        $this->db->delete($table);
    }


    /*
        fetch data from table with like condition
    */

    public function fetchTableDataLike($table,$where)
    {
        if(!empty($where))
        {
            $this->db->like($where);
        }

        $this->db->from($table);
        $query = $this->db->get();
        $res = $query->result();
        $result=array();
        foreach($res as $r)
        {
            $temp=array();
            $temp['Data']=$r;
            $result[]=$temp;
        }

        // echo $this->db->last_query();exit; 
        return $result;
    }

    /*
        pagination Query
    */
    public function fetchAll($limit='',$start='',$table,$where = array(),$order_by = '')
    {
        // echo $this->session->userdata('access');

        $this->db->select('*');

        if(!empty($order_by))
        {
            $this->db->order_by($order_by,'DESC');

        }        
       
        $this->db->from($table);
        // $this->db->join('videos', 'campaigns.camp_id = videos.camp_id');
        
        $this->db->where($where);
        if ($limit !== '' && $start !== ''){
             
            $query= $this->db->limit($limit,$start*$limit);

        }
        $query = $this->db->get();
                if ($query->num_rows() > 0) {
                        $allSites = array();
                        foreach ($query->result() as $row) {
                        $data = array();
                        $data['Data']=$row;
                        $allSites[]=$data;
        }

        return $allSites;
        }
        return false;

    }
    
 
    public function record_count_all(){
        
         $user = $this->ion_auth->user()->row();
         $userID = $user->id;


         $this->db->from('campaigns');
         // $this->db->join('videos', 'campaigns.camp_id = videos.camp_id');


         if($userID==1)
         {
           
         }
         else
         {
            $this->db->where('campaigns.user_id',$userID);
         }
        $query = $this->db->get();


         return  $query->num_rows();
        
        
    } 

}


    