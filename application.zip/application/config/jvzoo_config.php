<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| JVzoo Settings
|--------------------------------------------------------------------------
|
| ID of the JVZoo products, used on the JVZooListener
|
*/
$config['jvzoo']['fe']		= '287860';
$config['jvzoo']['oto1']	= '287862';
$config['jvzoo']['oto2']	= '288471';
$config['jvzoo']['oto3']	= '288473';
// $config['jvzoo']['oto4']	= '256640'; 
/* End of file jvzoo_config.php */
/* Location: ./application/config/jvzoo_config.php */
