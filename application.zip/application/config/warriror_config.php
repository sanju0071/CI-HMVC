<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| JVzoo Settings
|--------------------------------------------------------------------------
|
| ID of the JVZoo products, used on the JVZooListener
|
*/

$config['warrior']['fe']	 = 'wso_cqc9yr';
$config['warrior']['feds']	 = 'wso_t1483s';


$config['warrior']['oto1']	 = 'wso_nydx49';
$config['warrior']['oto1ds'] = 'wso_p5tn4d';

$config['warrior']['oto2']	 = 'wso_v40g2f';
$config['warrior']['oto2ds'] = 'wso_mf5ltx';

$config['warrior']['oto3']	 = 'wso_v1z7qf';
$config['warrior']['oto3ds'] = 'wso_lwj78r';

$config['warrior']['oto4']	 = 'wso_qp6s7t';
$config['warrior']['oto4ds'] = 'wso_rv7577';

$config['warrior']['oto5']	 = 'wso_vst1sh';
$config['warrior']['oto5ds'] = 'wso_zpx9xm';

$config['warrior']['secret'] = '386d0999fbbdf4728c7d2688054e738';

/* End of file jvzoo_config.php */
/* Location: ./application/config/jvzoo_config.php */
